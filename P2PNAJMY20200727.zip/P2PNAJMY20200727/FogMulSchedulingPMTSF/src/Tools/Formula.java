package Tools;
import java.io.IOException;
import java.math.BigDecimal;
//import java.util.HashSet;
import com.google.common.collect.*;
import java.util.*;
import Parameters.*;
import Resources.*;
import Solution.*;
public class Formula {
	public static ArrayList<Double> cloudDelay=new ArrayList<Double>();
    public static long ECtime=0;
	//�������ܺ�
	public static double fogPowerConsumption(FogSet fogSet,ArrayList<Integer> solutionF) {//�������Ľ�������
		double sumfpower=0;
		if(solutionF==null) {
			System.out.println("fog solution is null!");
			return -1;
		}
		for(int i=0;i<solutionF.size();i++) {
			Fog fog=fogSet.getFog(i);
			double a=fog.getA();
			double b=fog.getB();
			double c=fog.getC();
			sumfpower+=a*Math.pow(solutionF.get(i), 2)+b*solutionF.get(i)+c;
		}
		System.out.println("���豸�����ܺģ�"+Format.format2(sumfpower));
		return sumfpower;
	}
	
	//�������ܺ�
	public static double cloudPowerConsumption(CloudSet cloudSet,ArrayList<Integer> solutionM) {
		double sumcpower=0;
		int p=3;
		for(int i=0;i<solutionM.size();i++) {
			Cloud cloud=cloudSet.getCloud(i);
			double A=cloud.getA();
			int B=cloud.getB();
			int m=solutionM.get(i);
			sumcpower+=m*(A*Math.pow(cloud.getFrequency(), p)+B);
		}
		System.out.println("���豸�����ܺģ�"+Format.format2(sumcpower));
		return sumcpower;
	}
	
	//�������ӳ�ʱ��
	public static double fogComputeDelay(FogSet fogSet,ArrayList<Integer> solutionF) {
		if(solutionF==null) {
			System.out.println("fog solution is null!");
			return -1;
		}
		double sumfdelay=0;
		for(int i=0;i<solutionF.size();i++) {
			Fog fog=fogSet.getFog(i);
			int v=fog.getServiceRate();
			sumfdelay+=(double)1/(v-solutionF.get(i));
		}
		System.out.println("���豸�����ӳ٣�"+Format.format5(sumfdelay));
		return sumfdelay;
	}
	    //�Ŷ���EC��ʽ
	public static double EC(int m,int u) {
		BigDecimal ur=new BigDecimal(u);
		double p=u/m;
		BigDecimal sum=new BigDecimal(0.0);
		ArrayList<BigDecimal> arrk=new ArrayList<BigDecimal>();
		arrk.add(new BigDecimal(1));
		ArrayList<BigDecimal> arrpm=new ArrayList<BigDecimal>();
		arrpm.add(new BigDecimal(1));
		for(int k=0;k<m;k++) {
			sum=sum.add(arrpm.get(k).divide(arrk.get(k),6,BigDecimal.ROUND_DOWN));
			arrk.add(arrk.get(k).multiply(new BigDecimal(k+1)));
			arrpm.add(arrpm.get(k).multiply(ur));
		}
		BigDecimal v=arrpm.get(m).divide(arrk.get(m),6,BigDecimal.ROUND_DOWN);
		arrk=null;
		arrpm=null;
		return v.divide(v.add(sum.multiply(new BigDecimal(1-p))),6).doubleValue();
		
	}
	
	//�������ӳ�ʱ��
	public static double cloudComputeDelay (CloudSet cloudSet,ArrayList<Integer> solutionC,ArrayList<Integer> solutionM, Table<Integer,Integer,Double> table) {
		
		if(solutionC==null) {
			System.out.println("cloud solution is null!");
			return -1;
		}
		double sumcdelay=0;
		for(int i=0;i<solutionC.size();i++) {
//			cloudDelay.add(0.0);
			Cloud cloud=cloudSet.getCloud(i);
			int m=solutionM.get(i);
			int K=cloud.getCyclePerTask();
			double f=cloud.getFrequency();
			int y=solutionC.get(i);
			if(y==0) {
				sumcdelay+=0;
			}else {
				if(!table.contains(i, m)) {
					double EC;
					if((m*f/K-y)!=0) {
						 EC=Formula.EC(m, (int)((y*K)/f))/(m*f/K-y);
//						cloudDelay.add(EC+K/f);
						sumcdelay+=EC+K/f;
					}else {
						 EC=Formula.EC(m, (int)((y*K)/f))/0.1;
//						cloudDelay.add(EC+K/f);
						sumcdelay+=EC+K/f;
					}
					if(m>=3000) {
						table.put(i, m, EC);
					}
					
					
				}else {
//					cloudDelay.add(map.get(m)+K/f);
					sumcdelay+=table.get(i, m)+K/f;
				}
				
				
			}
			
		}
		System.out.println("���豸�����ӳ٣�"+Format.format5(sumcdelay));
//		System.out.println(cloudDelay);
		return sumcdelay;
	}
	
	//��������ͨ���ӳ�ʱ��
	public static double commDelay(CommuDelayMatrix CDM,ArrayList<ArrayList<Integer>> solutionFC) {
		double[][] d=CDM.getCommuDelayMatrix();
		double sumcommudelay=0;
		for(int i=0;i<d.length;i++) {
			for(int j=0;j<d[0].length;j++) {
				sumcommudelay+=d[i][j]*solutionFC.get(i).get(j);
			}
		}
		System.out.println("ͨ���ӳ٣�"+Format.format5(sumcommudelay));
		return sumcommudelay;
	}
	
	//�����ӡ���
	public static void PrintResult(String ff,int nth,Solution solution) {
		
		TotalResource tr=new TotalResource(ff,nth);
//		tr.getFogset().printFogSet();
//		tr.getCloudset().printCloudSet();
		solution.PrintSolution();
		if(!ValidationChecking.OffloadBalanceChecking(tr.getFogset(), solution.getSolutionF(), solution.getSolutionC(), solution.getSolutionFC())) {
			System.out.println("X+Y������L��fog��������");
		}
		if(!ValidationChecking.fogChecking(tr.getFogset(), solution.getSolutionF())) {
			System.out.println("fog�ⷶΧ����");
		}
		if(!ValidationChecking.cloudChecking(tr.getCloudset(), solution.getSolutionC(), solution.getSolutionM())) {
			System.out.println("cloud�ⷶΧ�����������ⷶΧ����");
		}
		if(!ValidationChecking.communicationChecking(solution.getSolutionFC(), tr.getaM())) {
			System.out.println("ͨ�ŷ�������");
		}
		System.out.println("********************************************************");
	}
	
	
	
	public static void ComputeSolution(String ff,int nth,Solution solution, Table<Integer,Integer,Double> table) {
		double sumfpower=0;
		double sumcpower=0;
		double sumfdelay=0;
		double sumcdelay=0;
		double sumcommudelay=0;
		TotalResource tr=new TotalResource(ff,nth);
//		tr.getFogset().printFogSet();
//		tr.getCloudset().printCloudSet();
//		System.out.println("�ӳ�Լ����"+tr.getDeadline());//deadline�����Ķ�
		int X=0;
		for(int i=0;i<solution.getSolutionF().size();i++) {
			X+=solution.getSolutionF().get(i);
		}
		System.out.println("����������"+tr.getTotalInput());
		System.out.println("���ش���ռ�ȣ�"+Format.format3((double)X/tr.getTotalInput()));
		sumfpower=fogPowerConsumption(tr.getFogset(),solution.getSolutionF());
		sumcpower=cloudPowerConsumption(tr.getCloudset(),solution.getSolutionM());
		sumfdelay=fogComputeDelay(tr.getFogset(),solution.getSolutionF());
		long start = System.currentTimeMillis();
		sumcdelay=cloudComputeDelay(tr.getCloudset(),solution.getSolutionC(),solution.getSolutionM(),table);
		ECtime = System.currentTimeMillis()-start;
		sumcommudelay=commDelay(tr.getdM(),solution.getSolutionFC());
		solution.setTotalPowerConsumption(sumfpower+sumcpower);
		solution.setTotalDelay(sumfdelay+sumcdelay+sumcommudelay);
	}
	
	
	
	
	public static void main(String[] args) {
		
		HashSet<Integer> set=new HashSet<Integer>();
		int t=10000;
		
		System.out.println(set);
		//����ECֵ
//		String ff="5_3_7";
//		ArrayList<Integer> a=new ArrayList<Integer>();
//		a.add(8168);
//		a.add(15116);
//		a.add(11817);
//		ArrayList<Integer> b=new ArrayList<Integer>();
//		b.add(15934);
//		b.add(927);
//		b.add(0);
//		ArrayList<Integer> c=new ArrayList<Integer>();
//		c.add(15116);
//		c.add(2318);
//		c.add(0);
//		ArrayList<Integer> d=new ArrayList<Integer>();
//		d.add(3645);
//		d.add(2102);
//		d.add(1183);
//		ArrayList<Integer> e=new ArrayList<Integer>();
//		e.add(25965);
//		e.add(0);
//		e.add(9124);
//		ArrayList<ArrayList<Integer>> solutionFC=new ArrayList<ArrayList<Integer>>();
//		solutionFC.add(a);
//		solutionFC.add(b);
//		solutionFC.add(c);
//		solutionFC.add(d);
//		solutionFC.add(e);
//		
//		ArrayList<Integer> f=new ArrayList<Integer>();
//		f.add(1754);
//		f.add(200);
//		f.add(200);
//		f.add(200);
//		f.add(200);
//		
//		ArrayList<Integer> g=new ArrayList<Integer>();
//		g.add(68828);
//		g.add(20463);
//		g.add(22124);
//		
//		ArrayList<Integer> h=new ArrayList<Integer>();
//		h.add(28679);
//		h.add(8898);
//		h.add(6147);
//		
//		Solution solution=new Solution(f,g,h,solutionFC,0,0);
//		PrintResult(ff,1,solution);	
		
/*	for(int i=0;i<1;i++) {
			double v=EC(ni[i],(int)(yj[i]/fi[i]))/(ni[i]*fi[i]-yj[i]);
			double u=1/fi[i];
		    System.out.println("v="+EC(4000,5882)/(4000*3.4-20000));
		    System.out.println("v="+EC(5882,5882)/(5882*3.4-20000));
		    System.out.println("v="+EC(5883,5882)/(5883*3.4-20000));
		    System.out.println("v="+EC(5900,5882)/(5900*3.4-20000));
			System.out.println("v="+EC(6000,5882)/(6000*3.4-20000));
			System.out.println("v="+EC(7000,5882)/(7000*3.4-20000));
			System.out.println("u="+1/3.4);

		}*/
	}
}
