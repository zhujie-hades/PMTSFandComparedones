package Tools;

import java.math.BigDecimal;
import java.text.DecimalFormat;
//����С��λ����
public class Format {
	public static String[][] format5(double[][] d) {
		  String[][] d1=new String[d.length][d[0].length] ;
		  for(int i=0;i<d.length;i++) {
			  for(int j=0;j<d[0].length;j++) {
				  d1[i][j]=String.format("%.6f", d[i][j]);
			  }
		  }
		  return d1;
	}
	
	public static double format5(double d) {
	return Double.parseDouble(String.format("%.6f", d));
}
	
	public static double format2(double d) {
		return Double.parseDouble(String.format("%.2f", d));
	}
	
	public static double format3(double d) {
		return Double.parseDouble(String.format("%.3f", d));
	}
	
	public static double format1(double d) {
		return Double.parseDouble(String.format("%.1f", d));
	}
	
	public static String formatbig(double d) {
		DecimalFormat df = new DecimalFormat("0.000000"); 
		  Double d1 = new Double(d);
		  return df.format(d1);
	}
	 

}
