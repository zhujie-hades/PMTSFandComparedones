package Tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

public class Io {
	public static final String location="D:\\FogScheduling\\TestCase";
	public static final String location2="D:\\FogScheduling\\ParetoFront";
	public static final String location3="D:\\FogScheduling\\Result";
	
	public static final String separa="****************************************";
	//�����ݣ�p�Ǵӵڼ��п�ʼ����һ����0����q�Ƕ�ȡ����+1
	public static void ReadFile(String ff,int p,int q,double[][] arr1) {
		File fromFile = new File(location+"\\"+ff+".txt");
		int i=0;
		BufferedReader read = null;
		try {
		read = new BufferedReader(new InputStreamReader(new FileInputStream(fromFile)));
		String data = null;
		while((data = read.readLine())!=null)
		{
			if(i<p) {
				i++;
			}else if(i>=p&&i<p+q-1){
				String[] arr = data.split("\t");
				for(int v=0;v<arr.length;v++) {
				arr1[i-p][v]=Double.parseDouble(arr[v]);
				}
				i++;
			}else{
				break;
			}
			
		}	
			read.close();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
	}
	
	public static void ReadFile(String ff,int p,int q,int[][] arr1) {//p�Ǵӵڼ��п�ʼ����һ����0����q�Ƕ�ȡ����
		File fromFile = new File(location+"\\"+ff+".txt");
		int i=0;
		BufferedReader read = null;
		try {
		read = new BufferedReader(new InputStreamReader(new FileInputStream(fromFile)));
		String data = null;
		while((data = read.readLine())!=null)
		{
			if(i<p) {
				i++;
			}else if(i>=p&&i<p+q-1){
				String[] arr = data.split("\t");
				for(int v=0;v<arr.length;v++) {
				arr1[i-p][v]=Integer.parseInt(arr[v]);
				}
				i++;
			}else{
				break;
			}
			
		}	
			read.close();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
	}
	
	//p�Ƕ�ȡ�ڼ���
	public static int ReadFile(String ff,int p) {
		File fromFile = new File(location+"\\"+ff+".txt");
		int i=0;
		int arr=0;
		BufferedReader read = null;
		try {
		read = new BufferedReader(new InputStreamReader(new FileInputStream(fromFile)));
		String data = null;
		while((data = read.readLine())!=null)
		{
			if(i<p) {
				i++;
			}else {		
				arr=Integer.parseInt(data);
				break; 	
			}
		}	
			read.close();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return arr;
	}
	
	
	public static void ReadFile(String ff,double[][] arr1) {
		File fromFile = new File(location+"\\"+ff+".txt");
		int i=0;
		BufferedReader read = null;
		try {
		read = new BufferedReader(new InputStreamReader(new FileInputStream(fromFile)));
		String data = null;	
		while((data = read.readLine())!=null)
		{
			String[] arr = data.split("\t");
			for(int j=0;j<arr.length;j++) {
			arr1[i][j]=Double.parseDouble(arr[j]);
			}
			i++;
		}	
			read.close();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void WriteFile(String location,String ff,int[][] d) throws IOException {
		try {
			File toFile =new File(location +"\\"+ff+".txt");
			toFile.createNewFile();
			BufferedWriter out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile,true)));
			for(int i=0;i<d.length;i++) {
				for(int j=0;j<d[0].length;j++) {
					out.append(d[i][j]+"\t");
					out.flush();
				}
				out.append("\r\n");
				out.flush();
			}
			out.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public static void WriteFile(String location,String ff,double[][] d) throws IOException {
		try {
			File toFile =new File(location +"\\"+ff+".txt");
			toFile.createNewFile();
			BufferedWriter out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile,true)));
			for(int i=0;i<d.length;i++) {
				for(int j=0;j<d[0].length;j++) {
					out.append(d[i][j]+"\t");
					out.flush();
				}
				out.append("\r\n");
				out.flush();
			}
			out.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void WriteFile(String location,String ff,String[][] d) throws IOException {
		try {
			File toFile =new File(location +"\\"+ff+".txt");
			toFile.createNewFile();
			BufferedWriter out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile,true)));
			for(int i=0;i<d.length;i++) {
				for(int j=0;j<d[0].length;j++) {
					out.append(d[i][j]+"\t");
					out.flush();
				}
				out.append("\r\n");
				out.flush();
			}
			out.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void WriteFile(String location,String ff,int[] d) throws IOException {
		try {
			File toFile =new File(location +"\\"+ff+".txt");
			toFile.createNewFile();
			BufferedWriter out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile,true)));
			for(int i=0;i<d.length;i++) {
				
					out.append(d[i]+"\t");
					out.flush();
			}
			out.append("\r\n");
			out.flush();
			out.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void WriteFile(String location,String ff,double[] d) throws IOException {
		try {
			File toFile =new File(location +"\\"+ff+".txt");
			toFile.createNewFile();
			BufferedWriter out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile,true)));
			for(int i=0;i<d.length;i++) {
				
					out.append(d[i]+"\t");
					out.flush();
			}
			out.append("\r\n");
			out.flush();
			out.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void WriteFile(String location,String ff,int a) throws IOException {
		try {
			File toFile =new File(location +"\\"+ff+".txt");
			toFile.createNewFile();
			BufferedWriter out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile,true)));
			out.append(a+"\r\n");
			out.flush();
			out.close();
			}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void WriteFile(String location,String ff,String a) throws IOException {
		try {
			File toFile =new File(location +"\\"+ff+".txt");
			toFile.createNewFile();
			BufferedWriter out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(toFile,true)));
			out.append(a+"\r\n");
			out.flush();
			out.close();
			}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static int getTextLines(String ff) throws IOException {
		String path = location +"\\"+ff+".txt";// �����ļ�·��
		FileReader fr = new FileReader(path); //���ﶨ��һ���ַ������������Ľڵ��������ڶ�ȡ�ļ���һ���ַ�һ���ַ��Ķ�ȡ��
		BufferedReader br = new BufferedReader(fr); // �ڶ���õ����������׽�һ�������������ڸ���Ч�ʵĶ�ȡ�ļ���һ��һ�еĶ�ȡ��
		int x = 0; // ����ͳ����������0��ʼ
		while(br.readLine() != null) { // readLine()�����ǰ��ж��ģ�����ֵ�����е�����
		x++; // ÿ��һ�У������x�ۼ�1
		}
		return x; //�����ܵ�����
		}
	
	public static int getNth(String ff) throws IOException {
		int fNum=Io.ReadFile(ff, 0);
		int totalline=16+2*fNum;
		int textLine=getTextLines(ff);
		return textLine/totalline;
	}
	public static void main(String[] args) throws IOException {
		//����
		/*		double[][] a=new double[5][3];
		Io.ReadFile("textd", a);
		for(int i=0;i<5;i++) {
			for(int j=0;j<3;j++) {
				System.out.print(a[i][j]+"  ");
			}
			System.out.println();
		}
		
		try {
			Io.WriteFile(Io.location,"test", a);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		String ff="1_6_6~8";
		System.out.println(getNth(ff));
	}
}
