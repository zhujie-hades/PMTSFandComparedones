package Parameters;

import java.io.IOException;
import java.util.Random;

import Tools.Format;
import Tools.Io;

public class GenerateTestCase {
	public static final String separa="****************************************";
	
	public static double[] GenerateF(int m){
		Random r=new Random();
		double[] f=new double[m];
		boolean flag=true;
		while(flag) {
			double sum=0;
			for(int i=0;i<m;i++) {
				f[i]=Format.format1(r.nextDouble()*m+1);
				sum+=1/f[i];
			}
			if(Format.format1(sum)<1.2&&Format.format1(sum)>0.8) {
				flag=false;
			}
		}	
		return f;
	}
	
	public static void run(int t,int parameterL,int parameterU) throws IOException {
	
			Random r=new Random();
			for(int p=1;p<11;p++) {
				for(int q=p-4;q<7;q++) {
					int count =t;
					while(count>0) {
						int n=p;
						if(q<1) {
							q=1;
						}
						int m=q;
						int[] Deadline= {5,6,7,8,9,10};
						int deadline=Deadline[r.nextInt(Deadline.length)];
						String name=n+"_"+m+"_"+parameterL+"~"+parameterU;
						Io.WriteFile(Io.location,name, n);
						Io.WriteFile(Io.location,name, m);
						Io.WriteFile(Io.location,name, deadline);
						double[][] abc=new double[3][n];
						for(int i=0;i<3;i++) {
							for(int j=0;j<n;j++) {
								abc[i][j]=Format.format2(5*r.nextDouble());
							}
						}
						Io.WriteFile(Io.location,name, abc);
						int[] xmax=new int[n];
						int[] v=new int[n];
						int[] l=new int[n];
						for(int i=0;i<n;i++) {
							xmax[i]=r.nextInt(3001)+1000;
							v[i]= r.nextInt(4)+ xmax[i]+1;
							l[i]=r.nextInt(2*xmax[i])+parameterL*xmax[i];
						}
						Io.WriteFile(Io.location,name, xmax);
						Io.WriteFile(Io.location,name, v);
						Io.WriteFile(Io.location,name, l);
						double[] A=new double[m];
						int[] B=new int[m];
						int[] machineMax=new int[m];
						for(int i=0;i<m;i++) {
							A[i]=Format.format3(r.nextDouble()*9+1);
							B[i]= r.nextInt(90)+10;
							machineMax[i]=r.nextInt(6001)+10000;
						}

						Io.WriteFile(Io.location,name, A);
						Io.WriteFile(Io.location,name, B);
						Io.WriteFile(Io.location,name, machineMax);
						Io.WriteFile(Io.location,name, GenerateF(m));
						Io.WriteFile(Io.location,name, separa);
						double[][] d=new double[n][m];
							for(int i=0;i<n;i++) {
								for(int j=0;j<m;j++) {
									d[i][j]=Format.format5(r.nextDouble()*0.00005+0.00005);
								}
							}
							Io.WriteFile(Io.location,name, Format.format5(d));
							Io.WriteFile(Io.location,name, separa);
							int[][] lamax=new int[n][m];
							for(int i=0;i<n;i++) {
								for(int j=0;j<m;j++) {
									lamax[i][j]=r.nextInt(l[i]-l[i]/(m*2)+1)+ l[i]/(m*2);
								}
							}
							Io.WriteFile(Io.location,name, lamax);
							   Io.WriteFile(Io.location,name, separa);
							   count--;
					}
					
				}
			}
	}
	
	
	
/*	public static void run(int t,int parameterL,int parameterU) throws IOException {
		while(t!=0) {
			Random r=new Random();
			int n=r.nextInt(10)+1;
			int m=r.nextInt(6)+1;
			int[] Deadline= {5,6,7,8,9,10};
			int deadline=Deadline[r.nextInt(Deadline.length)];
			String name=n+"_"+m+"_"+parameterL+"~"+parameterU;
			Io.WriteFile(Io.location,name, n);
			Io.WriteFile(Io.location,name, m);
			Io.WriteFile(Io.location,name, deadline);
			double[][] abc=new double[3][n];
			for(int i=0;i<3;i++) {
				for(int j=0;j<n;j++) {
					abc[i][j]=Format.format2(5*r.nextDouble());
				}
			}
			Io.WriteFile(Io.location,name, abc);
			int[] xmax=new int[n];
			int[] v=new int[n];
			int[] l=new int[n];
			for(int i=0;i<n;i++) {
				xmax[i]=r.nextInt(3001)+1000;
				v[i]= r.nextInt(4)+ xmax[i]+1;
				l[i]=r.nextInt(2*xmax[i])+parameterL*xmax[i];
			}
			Io.WriteFile(Io.location,name, xmax);
			Io.WriteFile(Io.location,name, v);
			Io.WriteFile(Io.location,name, l);
			double[] A=new double[m];
			int[] B=new int[m];
			int[] machineMax=new int[m];
			for(int i=0;i<m;i++) {
				A[i]=Format.format3(r.nextDouble()*9+1);
				B[i]= r.nextInt(90)+10;
				machineMax[i]=r.nextInt(6001)+10000;
			}
			Io.WriteFile(Io.location,name, A);
			Io.WriteFile(Io.location,name, B);
			Io.WriteFile(Io.location,name, machineMax);
			Io.WriteFile(Io.location,name, GenerateF(m));
			Io.WriteFile(Io.location,name, separa);
			double[][] d=new double[n][m];
				for(int i=0;i<n;i++) {
					for(int j=0;j<m;j++) {
						d[i][j]=Format.format5(r.nextDouble()*0.00005+0.00005);
					}
				}
			Io.WriteFile(Io.location,name, Format.format5(d));
			Io.WriteFile(Io.location,name, separa);
			int[][] lamax=new int[n][m];
			for(int i=0;i<n;i++) {
				for(int j=0;j<m;j++) {
					lamax[i][j]=r.nextInt(l[i]-l[i]/(m*2)+1)+ l[i]/(m*2);
				}
			}
		   Io.WriteFile(Io.location,name, lamax);
		   Io.WriteFile(Io.location,name, separa);
		   t--;
		}
	
	}*/
	
	public static void main(String[] args) throws IOException {
		int t=10;
		GenerateTestCase.run(t,0,2);
	}
}
