package ParetoFront;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;

import Solution.Solution;
import Tools.Format;
import Tools.Io;

public class ParetoFrontSet {   
	
	ArrayList<ParetoFront> set;
	int num;//��ֵͬ������
	String ff;
	int nth;
	
	public void computeARPD(ParetoFrontSet R)
	{
//		double minDelay = R.getbestDelay();
		int n = R.getSet().size();
		double minEDelay = R.getSet().get(0).getTotalDelay();
		double maxEDelay = R.getSet().get(0).getTotalDelay();
		double minEconsumption =  R.getSet().get(0).getTotalPowerConsumption();
		double maxEconsumption =  R.getSet().get(0).getTotalPowerConsumption();
		for(int i=1;i<n;i++)
		{
			ParetoFront ParetoFront = R.getSet().get(i);
			if(ParetoFront.getTotalDelay()>maxEDelay) maxEDelay = ParetoFront.getTotalDelay();
			if(minEDelay>ParetoFront.getTotalDelay()) minEDelay = ParetoFront.getTotalDelay();
			if(ParetoFront.getTotalPowerConsumption()>maxEconsumption) maxEconsumption = ParetoFront.getTotalPowerConsumption();
			if(minEconsumption>ParetoFront.getTotalPowerConsumption()) minEconsumption = ParetoFront.getTotalPowerConsumption();
		}
		int m=set.size();
		for(int i=0;i<m;i++)
		{
			this.set.get(i).computArpd(minEDelay, maxEDelay,minEconsumption,maxEconsumption);
		}
	}
	
	public double AverageQuality()//ֵԽСԽ��
	{
		
		double AQ = 0;
		int size = set.size();
		for(int i=0;i<=50;i++)
		{
			double lambda1 = (double)i/50;
			double lambda2 = (double)(50-i)/50;
			double minvalue = -1;
			for(int j=0;j<size;j++)
			{
				ParetoFront x = set.get(j);
				double value = Math.max(lambda1*x.getDelay_arpd(), lambda2*x.getPowerconsumption_arpd())+0.01*(lambda1*x.getDelay_arpd()+ lambda2*x.getPowerconsumption_arpd());
				if(minvalue>0) {if(minvalue>value) minvalue = value;}
				else minvalue = value;
			}
			AQ += minvalue;
		}
		
		return AQ/51;
	}
	
	
	public ParetoFrontSet intersection(ParetoFrontSet optSet)
	{
		ParetoFrontSet PFSet = new ParetoFrontSet(ff,nth);
		int size = optSet.getSet().size();
//		String contri = this.set.get(0).getContributor();
		for(int i=0;i<size;i++)
		{
			ParetoFront pf = optSet.getSet().get(i);
			if(ifcontains(pf))
			{
				PFSet.getSet().add(pf);
			}
//			else System.out.println(contri+"vs"+pf.getContributor());
		}
		return PFSet;
	}
	
	public boolean ifcontains(ParetoFront pf) {
		boolean flag=false;
		for(int i=0;i<set.size();i++) {
			ParetoFront pf2=set.get(i);
			if(pf2.equals(pf)) {
				flag=true;
				break;
			}
		}
		return flag;
	}
	
	
	public double MaximumSpread(ParetoFrontSet optSet)//ֵԽ��Խ��
	{
//		optSet.print();
//		System.out.println("------------------------");
//		this.print();
		ParetoFrontSet intersaction = this.intersection(optSet);
		if(intersaction.getSet().size()==0) 
			return 0;
		double min_opt_Delay = optSet.getSet().get(0).getDelay_arpd();
		double minEDelay = intersaction.getSet().get(0).getDelay_arpd();
		double max_opt_Delay = optSet.getSet().get(0).getDelay_arpd();	
		double maxEDelay = intersaction.getSet().get(0).getDelay_arpd();
		double minRconsumption = optSet.getSet().get(0).getPowerconsumption_arpd();
		double minEconsumption = intersaction.getSet().get(0).getPowerconsumption_arpd();
		double maxRconsumption = optSet.getSet().get(0).getPowerconsumption_arpd();
		double maxEconsumption = intersaction.getSet().get(0).getPowerconsumption_arpd();
		int sizeE = intersaction.getSet().size();
		for(int i=1;i<sizeE;i++)
		{
			ParetoFront ParetoFront = intersaction.getSet().get(i);
			if(ParetoFront.getDelay_arpd()>maxEDelay) maxEDelay = ParetoFront.getDelay_arpd();
			if(minEDelay>ParetoFront.getDelay_arpd()) minEDelay = ParetoFront.getDelay_arpd();
			if(ParetoFront.getPowerconsumption_arpd()>maxEconsumption) maxEconsumption = ParetoFront.getPowerconsumption_arpd();
			if(minEconsumption>ParetoFront.getPowerconsumption_arpd()) minEconsumption = ParetoFront.getPowerconsumption_arpd();
		}
		int sizeopt = optSet.getSet().size();
		for(int i=0;i<sizeopt;i++)
		{
			ParetoFront ParetoFront = optSet.getSet().get(i);
			if(ParetoFront.getDelay_arpd()>max_opt_Delay) max_opt_Delay = ParetoFront.getDelay_arpd();
			if(min_opt_Delay>ParetoFront.getDelay_arpd()) min_opt_Delay = ParetoFront.getDelay_arpd();
			if(ParetoFront.getPowerconsumption_arpd()>maxRconsumption) maxRconsumption = ParetoFront.getPowerconsumption_arpd();
			if(minRconsumption>ParetoFront.getPowerconsumption_arpd()) minRconsumption = ParetoFront.getPowerconsumption_arpd();
		}
		if(max_opt_Delay-min_opt_Delay==0||maxRconsumption-minRconsumption==0) return 1;
		return Math.sqrt((Math.pow(((maxEDelay-minEDelay)/(max_opt_Delay-min_opt_Delay)), 2)+Math.pow(((maxEconsumption-minEconsumption)/(maxRconsumption-minRconsumption)), 2))/2);
	}
	
		public double distanceMetricAvg(ParetoFrontSet R)//ֵԽСԽ��
	{
//		R.print();
//		System.out.println("------------------------");
//		this.print();
		double DelayRange = 0;
		double minDelay = set.get(0).getDelay_arpd();
		double maxDelay = set.get(0).getDelay_arpd();		
		double consumptionRange = 0;
		double minconsumption = set.get(0).getPowerconsumption_arpd();
		double maxconsumption = set.get(0).getPowerconsumption_arpd();
		
		int sizeE = set.size();
		for(int i=1;i<sizeE;i++)
		{
			ParetoFront ParetoFront = set.get(i);
			if(ParetoFront.getDelay_arpd()>maxDelay) maxDelay = ParetoFront.getDelay_arpd();
			if(minDelay>ParetoFront.getDelay_arpd()) minDelay = ParetoFront.getDelay_arpd();
			if(ParetoFront.getPowerconsumption_arpd()>maxconsumption) maxconsumption = ParetoFront.getPowerconsumption_arpd();
			if(minconsumption>ParetoFront.getPowerconsumption_arpd()) minconsumption = ParetoFront.getPowerconsumption_arpd();
		}
		int sizeR = R.getSet().size();
		for(int i=0;i<sizeR;i++)
		{
			ParetoFront ParetoFront = R.getSet().get(i);
			if(ParetoFront.getDelay_arpd()>maxDelay) maxDelay = ParetoFront.getDelay_arpd();
			if(minDelay>ParetoFront.getDelay_arpd()) minDelay = ParetoFront.getDelay_arpd();
			if(ParetoFront.getPowerconsumption_arpd()>maxconsumption) maxconsumption = ParetoFront.getPowerconsumption_arpd();
			if(minconsumption>ParetoFront.getPowerconsumption_arpd()) minconsumption = ParetoFront.getPowerconsumption_arpd();
		}
		
		DelayRange = maxDelay-minDelay;
		consumptionRange = maxconsumption - minconsumption;
		if(DelayRange==0||consumptionRange==0) {
			if(ifcontains(R.getSet().get(0))) {
				return 0;
			}else {
				return 1;
			}
				
		}
//		System.out.println("Delayrange="+DelayRange+" ddRange="+ddRange);
		
		double disSummary = 0;
		for(int i=0;i<sizeR;i++)
		{
			ParetoFront xR = R.getSet().get(i);
//			System.out.println("xR="+xR.toString());
			double mindistance = 10000;
			for(int j=0;j<sizeE;j++)
			{
				ParetoFront x = set.get(j);
//				System.out.println("x="+x.toString());
				double distanceOnDelay = (x.getDelay_arpd()-xR.getDelay_arpd())/DelayRange;
				double distanceOnconsumption = (x.getPowerconsumption_arpd()-xR.getPowerconsumption_arpd())/consumptionRange;
				double distance = Math.max(distanceOnDelay, distanceOnconsumption);	
				if(mindistance>distance) mindistance = distance;
//				System.out.println("distanceOnDelay="+distanceOnDelay+" distanceOndd="+distanceOndd+"  distance="+distance+" mindistance="+mindistance);
			}
			disSummary += mindistance;
		}
		return disSummary/sizeR;
	}
	
	public double distanceMetricMax(ParetoFrontSet R)//ֵԽСԽ��
	{
		double DelayRange = 0;
		double minDelay = set.get(0).getDelay_arpd();
		double maxDelay = set.get(0).getDelay_arpd();		
		double consumptionRange = 0;
		double minconsumption = set.get(0).getPowerconsumption_arpd();
		double maxconsumption = set.get(0).getPowerconsumption_arpd();
		
		int sizeE = set.size();
		for(int i=1;i<sizeE;i++)
		{
			ParetoFront ParetoFront = set.get(i);
			if(ParetoFront.getDelay_arpd()>maxDelay) maxDelay = ParetoFront.getDelay_arpd();
			if(minDelay>ParetoFront.getDelay_arpd()) minDelay = ParetoFront.getDelay_arpd();
			if(ParetoFront.getPowerconsumption_arpd()>maxconsumption) maxconsumption = ParetoFront.getPowerconsumption_arpd();
			if(minconsumption>ParetoFront.getPowerconsumption_arpd()) minconsumption = ParetoFront.getPowerconsumption_arpd();
		}
		int sizeR = R.getSet().size();
		for(int i=0;i<sizeR;i++)
		{
			ParetoFront ParetoFront = R.getSet().get(i);
			if(ParetoFront.getDelay_arpd()>maxDelay) maxDelay = ParetoFront.getDelay_arpd();
			if(minDelay>ParetoFront.getDelay_arpd()) minDelay = ParetoFront.getDelay_arpd();
			if(ParetoFront.getPowerconsumption_arpd()>maxconsumption) maxconsumption = ParetoFront.getPowerconsumption_arpd();
			if(minconsumption>ParetoFront.getPowerconsumption_arpd()) minconsumption = ParetoFront.getPowerconsumption_arpd();
		}
		
		DelayRange = maxDelay-minDelay;
		consumptionRange = maxconsumption - minconsumption;
		if(DelayRange==0||consumptionRange==0) {
			if(ifcontains(R.getSet().get(0))) {
				return 0;
			}else {
				return 1;
			}
				
		}
		double maxdistance = 0;
		for(int i=0;i<sizeR;i++)
		{
			ParetoFront xR = R.getSet().get(i);
			
			double mindistance = 10000;
			for(int j=0;j<sizeE;j++)
			{
				ParetoFront x = set.get(j);
				double distanceOnDelay = (x.getDelay_arpd()-xR.getDelay_arpd())/DelayRange;
				double distanceOnconsumption = (x.getPowerconsumption_arpd()-xR.getPowerconsumption_arpd())/consumptionRange;
				double distance = Math.max(distanceOnDelay, distanceOnconsumption);	
				if(mindistance>distance) mindistance = distance;
			}
			if(mindistance>maxdistance) maxdistance = mindistance;
		}
		return maxdistance;
	}
	
	/*	public double CMetric(ParetoFrontSet E)//�Ƚ������㷨֮��ĺû��ģ������ʺ����Ž�Ƚ�
	{
		double metric = 0;
		int sizeE = E.getSet().size();
		int size = this.set.size();
		for(int i=0;i<sizeE;i++)
		{
			ParetoFront ParetoFront = E.getSet().get(i);
			for(int j=0;j<size;j++)
			{
				ParetoFront x = set.get(j);
				if(x.compare(ParetoFront)==C.ParetoFront_LESS)
				{
					metric++;
					break;
				}
			}
		}
		return metric/sizeE;
	}*/
	
	public void print() throws IOException
	{
//		for(int i=0;i<set.size();i++)
//			set.get(i).print();
//		Iterator<ParetoFront> it=set.iterator();
//		while(it.hasNext()) {
//			ParetoFront temp=it.next();
//			System.out.println(temp);
//			String[][] str= {{Double.toString(temp.getTotalDelay()),Format.formatbig(temp.getTotalPowerConsumption())}};
////			String str2=;
//			Io.WriteFile(Io.location2,"ParetoFrontcommu_"+ff, str);
//			
//		}
//		Io.WriteFile(Io.location2, "ParetoFrontcommu_"+ff, Io.separa);
		Iterator<ParetoFront> it2=set.iterator();
		while(it2.hasNext()) {
			ParetoFront temp=it2.next();
			String[][] str= {{String.format("%.6f", temp.TotalDelay),String.format("%.6f", temp.TotalPowerConsumption)}};
			Io.WriteFile(Io.location2,"ParetoFrontR"+ff, str);
			
		}
		Io.WriteFile(Io.location2, "ParetoFrontR"+ff, Io.separa);
		System.out.println(set.size());
	}
	
	public ParetoFrontSet(String ff,int nth)
	{
		set = new ArrayList<ParetoFront>();
		num = 0;
		this.ff=ff;
		this.nth=nth;
	}
	
	
	
	public void setSet(ArrayList<ParetoFront> set) {
		int n=set.size();
		for(int i=0;i<n;i++) {
			ParetoFront pf=set.get(i).copy();
			this.set.add(pf);
		}
	}

	public void mergeWithSet(ParetoFrontSet anotherset)  //����R
	{
		if(this.set.size()==0) {
			Iterator<ParetoFront> it = anotherset.getSet().iterator();
			while(it.hasNext())
			{
				ParetoFront ParetoFront = it.next();
				this.set.add(new ParetoFront(ParetoFront.getTotalDelay(),ParetoFront.getTotalPowerConsumption()));
			}
		}else {
			
			int sizeE=this.set.size();
			int sizeaE=anotherset.getSet().size();
			for(int i=0;i<sizeaE;i++)
			   {
				boolean flag=true;
				ArrayList<ParetoFront> deletepf=new ArrayList<ParetoFront>();
				ParetoFront xaE = anotherset.getSet().get(i);
				for(int j=0;j<this.set.size();j++)
				{
					ParetoFront x = this.set.get(j);
					if((x.getTotalDelay()>=xaE.getTotalDelay())&&(x.getTotalPowerConsumption()>=xaE.getTotalPowerConsumption())) {
		        		deletepf.add(x);//(new ParetoFront(x.getTotalDelay(),x.getTotalPowerConsumption()));
		        		
		        	}else if((x.getTotalDelay()<=xaE.getTotalDelay())&&(x.getTotalPowerConsumption()<=xaE.getTotalPowerConsumption())){
		        		flag=false;
		        	}else {

		        		}
					
			        }
				if(flag==true) {
	        		ParetoFront newpf=xaE.copy();
	        		if(!this.set.contains(newpf)) {
	        			this.set.add(newpf);
	        	}
	        		if(deletepf.size()!=0) {
	        			for(int v=0;v<deletepf.size();v++) {
	        				this.set.remove(deletepf.get(v));
	        			}
	        		}
				}
			   }
			}

		
	}
	
	public ArrayList<ParetoFront> getSet() {
		return set;
	}

	public int getNum() {
		return num;
	}

	public void ComputeDistence(ParetoFrontSet R) {
		int sizeE = set.size();
		int sizeR = R.getSet().size();
		for(int i=0;i<sizeE;i++) {
			ParetoFront x = set.get(i);
			double mindistance=Double.MAX_VALUE;
			for(int j=0;j<sizeR;j++) {
				ParetoFront xR = R.getSet().get(j);
				double distance=Math.sqrt((Math.pow(x.getDelay_arpd()-xR.getDelay_arpd(), 2)+Math.pow(x.getPowerconsumption_arpd()-xR.getPowerconsumption_arpd(), 2)));
				if(mindistance>distance) mindistance=distance;
			}
			x.setDistance(mindistance);
		}
	}
	
	public boolean Contains(ParetoFront pf) {
		boolean flag=false;
		int sizeE = set.size();
		for(int i=0;i<sizeE;i++) {
			if(set.get(i).equals(pf)) {
				flag=true;
			}
		}
		return flag;
	}
	
	public void display() {
		for(int i=0;i<set.size();i++) {
			set.get(i).getSolution().PrintSolution();
			System.out.println();
		}
	}
/*	public HashMap<String,Double> Statistic(boolean print)
	{
//		if(print) 
//		{
//			System.out.println("===========================================");
//			for(int i=0;i<set.size();i++)
//				set.get(i).print();
//		}
		this.print();
		if(num==0) 
		{
			System.out.println("Empty Pareto Frontier Set");
			return null;
		}
		if(this.validation()==false)
		{
			System.out.println("WRONG Pareto Frontier Set");
			
			return null;
		}
		if(num==0) return null;
		HashMap<String,Integer> result = new HashMap<String,Integer>();
		Iterator<ParetoFront> it = set.iterator();
		while(it.hasNext())
		{
			ParetoFront ParetoFront = it.next();
			String contributor = ParetoFront.getContributor();
			if(result.containsKey(contributor)) 
				result.put(contributor, result.get(contributor)+1);
			else result.put(contributor, 1);
		}
		HashMap<String,Double> finalresult = new HashMap<String,Double>();
		Iterator<String> cit = result.keySet().iterator();
		while(cit.hasNext())
		{
			String method = cit.next();
			int connum = result.get(method);
			double ratio = (double)connum/(double)num;
			if(print)
			{
				System.out.println(method+"\t"+ratio);
			}
			finalresult.put(method, ratio);
		}
		return finalresult;
	}
	
	public boolean validation()
	{
		
		int size = set.size();
		for(int i=0;i<size;i++)
		{
			ParetoFront ParetoFront1 = set.get(i);
			for(int j=i+1;j<size;j++)
			{
				ParetoFront ParetoFront2 = set.get(j);
				int compare = ParetoFront1.compare(ParetoFront2);
				if(compare==C.ParetoFront_EQUARE&&!ParetoFront1.getContributor().equalsIgnoreCase(ParetoFront2.getContributor())) continue;
				if(compare!=C.ParetoFront_UNCOMPARABLE) 
				{
					System.out.println("Validation Error: "+ParetoFront1.toString()+" <> "+ParetoFront2.toString());
					this.print();
					return false;
				}
			}
		}		
		return true;
	}
	
	public boolean addParetoFront(ParetoFront ParetoFront)
	{
		//Delay=2188.0 dd=0.0
//		if(ParetoFront.getDelay()==2188)
//		{
//			System.out.println("Error come hereeeeeeeeeeeeeeeeee to add "+ParetoFront.toString());
//			this.print();
//		}
		HashSet<String> forcount = new HashSet<String>();
		if(num==0) 
		{
			set.add(ParetoFront);
			num++;
//			if(ParetoFront.getDelay()==2188)
//			{
//				System.out.println("num==0"+ParetoFront.toString()+" num="+num);
//				this.print();
//			}
			return true;
		}
		
		int size = set.size();
		int comparecase = -5;//һ�������ܵ�ֵ
		boolean iscomparable = false;
		int stopindex = -1;
		for(int i=0;i<size;i++)//ParetoFront̫������
		{
			
			ParetoFront obj = set.get(i);
			int compare = obj.compare(ParetoFront);
			forcount.add(obj.getvaluestring());
			if(compare == C.ParetoFront_LESS)
			{
//				if(ParetoFront.getDelay()==2188)
//				{
//					System.out.println("������ParetoFrontС�ģ�˵��ParetoFront�󣬿϶��Ӳ����� to add "+ParetoFront.toString()+" num="+num);
//					this.print();
//				}
				return false;//������ParetoFrontС�ģ�˵��ParetoFront�󣬿϶��Ӳ�����
			}
			if(compare == C.ParetoFront_EQUARE)
			{
				if(obj.contributor.equalsIgnoreCase(ParetoFront.contributor))
				{
//					if(ParetoFront.getDelay()==2188)
//					{
//						System.out.println("�����������ͬһ���ˣ���Ҫ�ӽ���"+ParetoFront.toString()+" num="+num);
//						this.print();
//					}
					return false;//�����������ͬһ���ˣ���Ҫ�ӽ���
				}
				else {
					
					comparecase = C.ParetoFront_EQUARE;
					iscomparable = true;//�����ɱȽϵ����
				}
			}
			if(compare == C.ParetoFront_MORE)//ParetoFront�Ǹ�С�����
			{
				
				comparecase = C.ParetoFront_MORE;
				iscomparable = true;//�����ɱȽϵ����
				stopindex = i;
				break;
			}
		}
		
		if(!iscomparable)//˵�������ɱȽ�
		{
			set.add(ParetoFront);
			num++;
//			if(ParetoFront.getDelay()==2188)
//			{
//				System.out.println("˵�������ɱȽ�"+ParetoFront.toString()+" num="+num);
//				this.print();
//			}
			return true;
		}
		
		if(comparecase==C.ParetoFront_EQUARE)//��ͬ�����ǲ�ͬ������
		{
			set.add(ParetoFront);
//			if(ParetoFront.getDelay()==2188)
//			{
//				System.out.println("��ͬ�����ǲ�ͬ������"+ParetoFront.toString()+" num="+num);
//				this.print();
//			}
			return true;
		}
		if(comparecase==C.ParetoFront_MORE)
		{
			ParetoFront toremove = set.get(stopindex);
			forcount.remove(toremove.getvaluestring());
//			System.out.println("remove "+forcount.toString());
			forcount.add(ParetoFront.getvaluestring());
//			System.out.println("add "+forcount.toString());
			set.set(stopindex, ParetoFront);
			for(int i=stopindex+1;i<size;i++)
			{
				if(set.get(i).compare(ParetoFront)==C.MORE)
				{
					forcount.remove(set.get(i).getvaluestring());
//					System.out.println("remove "+forcount.toString());

					set.remove(i);
					i--;
					size--;
				}
				else 
				{
					forcount.add(set.get(i).getvaluestring());
//					System.out.println("add "+forcount.toString());

				}
			}
			num = forcount.size();
//			if(ParetoFront.getDelay()==2188)
//			{
//				System.out.println("comparecase==C.ParetoFront_MORE"+ParetoFront.toString()+" num="+num);
//				this.print();
//			}
			return true;
		}
		
//		if(ParetoFront.getDelay()==2188)
//		{
//			System.out.println("final return "+ParetoFront.toString()+" num="+num);
//			this.print();
//		}
		return false;		
	}
	
		
	public static void main(String args[])
	{
		String[] methods = {"M1","M2","M3","M4"};
		Random r = new Random();
		ParetoFrontSet ParetoFrontSet = new ParetoFrontSet();
//		for(int i=0;i<200;i++)
//		{
//			ParetoFront ParetoFront = new ParetoFront(r.nextInt(10),r.nextInt(10),methods[r.nextInt(4)]);
//			ParetoFront.print();
//			System.out.println(ParetoFrontSet.addParetoFront(ParetoFront)+" num="+ParetoFrontSet.getNum()+"------------------");
//		}
		ParetoFront ParetoFront1 = new ParetoFront(0.0,0.0,methods[r.nextInt(4)]);
		ParetoFront1.print();
		ParetoFront ParetoFront2 = new ParetoFront(0.0,0.2,methods[r.nextInt(4)]);
		System.out.println(ParetoFrontSet.addParetoFront(ParetoFront1)+" num="+ParetoFrontSet.getNum()+"------------------");
		ParetoFrontSet.print();
		System.out.println(ParetoFrontSet.addParetoFront(ParetoFront2)+" num="+ParetoFrontSet.getNum()+"------------------");
		ParetoFrontSet.print();

		System.out.println("totalnum="+ParetoFrontSet.getNum());
		ParetoFrontSet.Statistic(true);
	}*/

}
