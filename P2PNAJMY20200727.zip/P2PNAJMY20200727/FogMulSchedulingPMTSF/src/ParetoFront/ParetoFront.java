package ParetoFront;

import java.util.Iterator;

import Solution.Solution;
import Tools.Io;

public class ParetoFront {
	double TotalDelay;
	double TotalPowerConsumption;
	double delay_arpd = -1;
	double powerconsumption_arpd=-1;
	String contributor;
	Solution solution;
	double distance=-1;
	int n;
	boolean flag;
	
	public ParetoFront(double totalDelay, double totalPowerConsumption) {
		super();
		TotalDelay = totalDelay;
		TotalPowerConsumption = totalPowerConsumption;
		n=1;
		this.flag=true;
	}
	
	
	
	public void setTotalDelay(double totalDelay) {
		TotalDelay = totalDelay;
	}



	public void setTotalPowerConsumption(double totalPowerConsumption) {
		TotalPowerConsumption = totalPowerConsumption;
	}



	public void computArpd(double bestdelay,double worstdelay,double bestconsumption,double worstconsumption)
	{
			this.delay_arpd=(TotalDelay-bestdelay)/(worstdelay-bestdelay);
			this.powerconsumption_arpd=(TotalPowerConsumption-bestconsumption)/(worstconsumption-bestconsumption);
		
	}
	
	public double getTotalDelay() {
		return TotalDelay;
	}
	
	public double getTotalPowerConsumption() {
		return TotalPowerConsumption;
	}

	public void setContributor(String contributor) {
		this.contributor = contributor;
	}

	public void setSolution(Solution solution) {
		Solution newS=new Solution(solution.getSolutionF(),solution.getSolutionC(),solution.getSolutionM(),solution.getSolutionFC(),solution.getTotalDelay(),solution.getTotalPowerConsumption()); 
		this.solution = newS;
	}

	public double getDelay_arpd() {
		return delay_arpd;
	}

	public double getPowerconsumption_arpd() {
		return powerconsumption_arpd;
	}

	public String getContributor() {
		return contributor;
	}

	public Solution getSolution() {
		return solution;
	}

	public ParetoFront copy() {
		ParetoFront pf2=new ParetoFront(this.TotalDelay,this.TotalPowerConsumption);
		pf2.contributor=this.contributor;
		pf2.solution=this.solution.copy();
		pf2.delay_arpd=this.delay_arpd;
		pf2.powerconsumption_arpd=this.powerconsumption_arpd;
		pf2.distance=this.distance;
		pf2.n=this.n;
		return pf2;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public double getDistance() {
		return distance;
	}
	
	public boolean equals(ParetoFront pf) {
		boolean flag=false;
		if(this.TotalDelay==pf.TotalDelay&&this.TotalPowerConsumption==pf.TotalPowerConsumption) {
			flag=true;
		}
		return flag;
	}



	public int getN() {
		return n;
	}



	public void setN(int n) {
		this.n = n;
	}



	public boolean getFlag() {
		return flag;
	}



	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	
	
	
}
