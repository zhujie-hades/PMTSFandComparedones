package Resources;
import java.util.*;

public class Cloud {
	 int cId;
	 int mNum;//��������
	 int cyclePerTask=1;
	 double Frequency;
	 double cloudDelay;
	 double A;
	 int B;
	
	public Cloud(int cId, double A,int B,int mNum, double Frequency) {
		this.cId=cId;
		this.A=A;
		this.B=B;
		this.mNum=mNum;
		this.Frequency = Frequency;
		
	}

	public int getcId() {
		return cId;
	}

	public int getmNum() {
		return mNum;
	}


	public int getCyclePerTask() {
		return cyclePerTask;
	}
	
	public double getFrequency() {
		return Frequency;
	}

	public void setCloudDelay(double cloudDelay) {
		this.cloudDelay = cloudDelay;
	}

	public double getCloudDelay() {
		return cloudDelay;
	}
	
	public double getA() {
		return A;
	}

	public int getB() {
		return B;
	}

	public void printCloud() {
		System.out.println("cId:"+cId);
		System.out.println("mNum:"+mNum);
		System.out.println("Frequency:"+Frequency);
		System.out.println("cloudDelay:"+cloudDelay);
		System.out.println("A:"+A);
		System.out.println("B:"+B);
	}
	
	

}
