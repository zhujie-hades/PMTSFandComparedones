package Resources;

import java.util.ArrayList;
import Experiment.CommuDelayGenerateIniSolution;
import Solution.Solution;
import Tools.Io;

public class TotalResource {
	CloudSet cloudset;
	FogSet fogset;
	CommuDelayMatrix dM;
	MaxAllocationMatrix aM;
	int deadline;
	int TotalInput=0;
	int[] xmax;
	int[] ymax;
	//�ۺ����еĹ̶�����
	public TotalResource(String ff,int nth) {
		cloudset=new CloudSet(ff,nth);
		fogset=new FogSet(ff,nth);
		dM=new CommuDelayMatrix(ff,nth);
		aM=new MaxAllocationMatrix(ff,nth);
		deadline=Io.ReadFile(ff, 2);
		xmax=new int[fogset.fNum];
		for(int i=0;i<fogset.fNum;i++) {
			TotalInput+=fogset.getfPowerParameter()[5][i];
			xmax[i]=(int)fogset.getfPowerParameter()[3][i];
		}
		int[] y_max=new int[cloudset.cNum];
		int[] y_nmax=new int[cloudset.cNum];
		for(int j=0;j<cloudset.cNum;j++) {
			for(int i=0;i<fogset.fNum;i++) {
				y_max[j]+=aM.getMaxAllocation(i, j);
			}
		}
		
		for(int i=0;i<cloudset.cNum;i++) {
			double f=cloudset.getCloud(i).getFrequency();
			y_nmax[i]=(int)((cloudset.getCloud(i).getmNum()-1)*f);
		}
		ymax=new int[cloudset.cNum];
		for(int i=0;i<cloudset.cNum;i++) {
			ymax[i]=Math.min(y_max[i], y_nmax[i]);
		}
		
	}

	public CloudSet getCloudset() {
		return cloudset;
	}

	public FogSet getFogset() {
		return fogset;
	}

	public CommuDelayMatrix getdM() {
		return dM;
	}

	public MaxAllocationMatrix getaM() {
		return aM;
	}

	public int getDeadline() {
		return deadline;
	}

	public int getTotalInput() {
		return TotalInput;
	}

	public int getYmax(int i) {
		return ymax[i];
	}
	


}
