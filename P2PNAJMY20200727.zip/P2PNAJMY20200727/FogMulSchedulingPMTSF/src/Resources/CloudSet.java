package Resources;
import java.util.*;
import Resources.Cloud;
import Resources.Fog;
import Tools.Io;
public class CloudSet {
	 int cNum;
	ArrayList<Cloud> cloudList ;
	 double[][] cParameters;

	public CloudSet(String ff,int nth) {//nthһ������ʵ���ĵ�n��ʵ�飬totallineһ������ʵ��������
		cNum=Io.ReadFile(ff, 1);
		int fNum=Io.ReadFile(ff, 0);
		int totalline=16+2*fNum;
		cParameters=new double[4][cNum];
		cloudList=new ArrayList<Cloud>();
		Io.ReadFile(ff, 9+(nth-1)*totalline, 5, cParameters);
		for(int i=0;i<cNum;i++) {
			cloudList.add(new Cloud(i,cParameters[0][i],(int)cParameters[1][i],(int)cParameters[2][i],cParameters[3][i]));
		}
	}

	public int getcNum() {
		return cNum;
	}

	public ArrayList<Cloud> getCloudList() {
		return cloudList;
	}
	
	public Cloud getCloud(int cId) {
		Cloud idCloud=null;
		Iterator<Cloud> iter=cloudList.iterator();
		while(iter.hasNext()) {
			Cloud cloud=iter.next();
			if(cloud.getcId()==cId) {
				idCloud=cloud;
			}
		}
		return idCloud;
	}
	
	public void printCloudSet() {
		System.out.println("���豸��Ϣ:");
		for(int i=0;i<cNum;i++) {
			Cloud cloud=getCloud(i);
			cloud.printCloud();
		}
		
	}
	
	public double[][] getcPowerParameter() {
		return cParameters;
	}	
			
}

