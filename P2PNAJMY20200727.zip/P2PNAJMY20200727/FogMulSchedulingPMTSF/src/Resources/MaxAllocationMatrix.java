package Resources;

import Tools.Io;
 //��ȡ����������������
public class MaxAllocationMatrix {
	   int[][] maxAllocationMatrix;
		public MaxAllocationMatrix (String ff,int nth) {
			int fNum=Io.ReadFile(ff, 0);
			int cNum=Io.ReadFile(ff, 1);
			int totalline=16+2*fNum;
			maxAllocationMatrix=new int[fNum][cNum];
			Io.ReadFile(ff, 15+fNum+(nth-1)*totalline, fNum+1, maxAllocationMatrix);;
		}
		
		public int[][] getMaxAllocationMatrix() {
			return maxAllocationMatrix;
		}
		
		
		public int getMaxAllocation(int fId,int cId) {
			return maxAllocationMatrix[fId][cId];
		}
		
		public void printMaxAllocation() {
			System.out.println("����֮����������������");
			for(int i=0;i<maxAllocationMatrix.length;i++) {
				for(int j=0;j<maxAllocationMatrix[0].length;j++) {
					System.out.print(maxAllocationMatrix[i][j]+"\t");
				}
				System.out.println();
			}
		}
		
		
}
