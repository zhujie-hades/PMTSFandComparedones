package Resources;
import java.util.*;

import Resources.Fog;
//import Parameters.Fog;
import Tools.Io;

public class FogSet {
	 int fNum;
	ArrayList<Fog> fogList;
	 double[][] fParameters;


	public FogSet(String ff,int nth) {
		fNum=Io.ReadFile(ff, 0);
		int totalline=16+2*fNum;
		fParameters=new double[6][fNum];
		fogList=new ArrayList<Fog>();
		Io.ReadFile(ff, 3+(nth-1)*totalline,7,fParameters);//���������
		for(int i=0;i<fNum;i++) {
			fogList.add(new Fog(i,fParameters[0][i],fParameters[1][i],fParameters[2][i],(int)fParameters[3][i],(int)fParameters[4][i],(int)fParameters[5][i]));
		}
	}

	public int getfNum() {
		return fNum;
	}

	public ArrayList<Fog> getFogList() {
		return fogList;
	}
	
	public Fog getFog(int fId) {
		Fog idFog=null;
		Iterator<Fog> iter=fogList.iterator();
		while(iter.hasNext()) {
			Fog fog=iter.next();
			if(fog.getfId()==fId) {
				idFog=fog;
			}
		}
		return idFog;
	}

	
	public void printFogSet() {
		System.out.println("���豸��Ϣ��");
		for(int i=0;i<fNum;i++) {
			Fog fog=getFog(i);
			fog.printFog();
		}
	}
	
	
	public double[][] getfPowerParameter () {
		return fParameters;
	}
	

	
	public static void main(String[] args) {
			
	}
}
