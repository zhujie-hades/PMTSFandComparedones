package Resources;

public class Fog {
	 int fId;
	 int maxTaskNum;
	 int serviceRate;
	 double a,b,c;
	 int TotalInput;
	public Fog(int fId,double a,double b,double c,int maxTaskNum,int serviceRate,int TotalInput) {
		this.fId=fId;
		this.a=a;
		this.b=b;
		this.c=c;
		this.maxTaskNum=maxTaskNum;
		this.serviceRate=serviceRate;
		this.TotalInput=TotalInput;
	}
	public int getfId() {
		return fId;
	}
	public int getMaxTaskNum() {
		return maxTaskNum;
	}
	public int getServiceRate() {
		return serviceRate;
	}
	public double getA() {
		return a;
	}
	public double getB() {
		return b;
	}
	public double getC() {
		return c;
	}
	public int getTotalInput() {
		return TotalInput;
	}
	
	public void printFog() {
		System.out.println("fId:"+fId);
		System.out.println("a:"+a);
		System.out.println("b:"+b);
		System.out.println("c:"+c);
		System.out.println("maxTaskNum:"+maxTaskNum);
		System.out.println("serviceRate:"+serviceRate);
		System.out.println("TotalInput:"+TotalInput);
	}

}
