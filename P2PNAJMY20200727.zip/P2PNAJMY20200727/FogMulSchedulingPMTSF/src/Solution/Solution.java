package Solution;

import java.util.ArrayList;

import Resources.CloudSet;
import Resources.FogSet;
import Tools.Format;
import Tools.Formula;

public class Solution {
	ArrayList<Integer> solutionF;
	ArrayList<Integer> solutionC;
	ArrayList<Integer> solutionM;
	ArrayList<ArrayList<Integer>> solutionFC;
	double TotalDelay;
	double TotalPowerConsumption;
	
	public Solution(ArrayList<Integer> solutionF,ArrayList<Integer> solutionC,ArrayList<Integer> solutionM,ArrayList<ArrayList<Integer>> solutionFC,
			double TotalDelay,double TotalPowerConsumption){
		this.solutionF=solutionF;
		this.solutionC=solutionC;
		this.solutionM=solutionM;
		this.solutionFC=solutionFC;
		this.TotalDelay=TotalDelay;
		this.TotalPowerConsumption=TotalPowerConsumption;
	}
	
	public Solution copy() {
		ArrayList<Integer> solutionf=new ArrayList<Integer>();
		for(int i=0;i<this.solutionF.size();i++) {
			solutionf.add(this.solutionF.get(i));
		}
		
		ArrayList<Integer> solutionc=new ArrayList<Integer>();
		ArrayList<Integer> solutionm=new ArrayList<Integer>();
		for(int i=0;i<this.solutionC.size();i++) {
			solutionc.add(this.solutionC.get(i));
			solutionm.add(this.solutionM.get(i));
		}
		ArrayList<ArrayList<Integer>> solutionfc=new ArrayList<ArrayList<Integer>>();
		for(int i=0;i<this.solutionF.size();i++) {
			
				ArrayList<Integer> a=new ArrayList<Integer>();
				for(int v=0;v<this.solutionC.size();v++) {
					a.add(this.solutionFC.get(i).get(v));
				}
				solutionfc.add(a);
			
		}
		Solution s=new Solution(solutionf,solutionc,solutionm,solutionfc,this.TotalDelay,this.TotalPowerConsumption);
		return s;
	}
	
	public void PrintSolution() {
		int u=solutionF.size();
		int v=solutionC.size();
		System.out.print("���豸��������"+"\t");
		for(int i=0;i<u;i++) {
			System.out.print(solutionF.get(i)+"\t");
		}
		System.out.println();
		System.out.print("���豸��������"+"\t");
		for(int i=0;i<v;i++) {
			System.out.print(solutionC.get(i)+"\t");
		}
		System.out.println();
		System.out.print("���豸������������"+"\t");
		for(int i=0;i<v;i++) {
			System.out.print(solutionM.get(i)+"\t");
		}
		System.out.println();
		System.out.println("���Ʒ������");
		System.out.print("F"+"\t");
		for(int j=0;j<v;j++) {
			System.out.print("C"+j+"\t");
		}
		System.out.println();
		for(int i=0;i<u;i++) {
			for(int j=0;j<v+1;j++) {
				if(j==0) {
					System.out.print(solutionF.get(i)+"\t");
				}else {
					System.out.print(solutionFC.get(i).get(j-1)+"\t");
				}
				
			}
			System.out.println();
		}
		System.out.println("���ܺ�Ϊ��"+Format.formatbig(TotalPowerConsumption));
		System.out.println("���ӳ�Ϊ��"+Format.format5(TotalDelay));
		
	}

	public void setSolutionF(ArrayList<Integer> solutionF) {
		this.solutionF = solutionF;
	}

	public void setSolutionC(ArrayList<Integer> solutionC) {
		this.solutionC = solutionC;
	}

	public void setSolutionM(ArrayList<Integer> solutionM) {
		this.solutionM = solutionM;
	}

	public void setSolutionFC(ArrayList<ArrayList<Integer>> solutionFC) {
		this.solutionFC = solutionFC;
	}

	public void setTotalDelay(double totalDelay) {
		TotalDelay = totalDelay;
	}

	public void setTotalPowerConsumption(double totalPowerConsumption) {
		TotalPowerConsumption = totalPowerConsumption;
	}

	public ArrayList<Integer> getSolutionF() {
		return solutionF;
	}

	public ArrayList<Integer> getSolutionC() {
		return solutionC;
	}

	public ArrayList<Integer> getSolutionM() {
		return solutionM;
	}

	public ArrayList<ArrayList<Integer>> getSolutionFC() {
		return solutionFC;
	}

	public double getTotalDelay() {
		return TotalDelay;
	}

	public double getTotalPowerConsumption() {
		return TotalPowerConsumption;
	}
	
	
}
