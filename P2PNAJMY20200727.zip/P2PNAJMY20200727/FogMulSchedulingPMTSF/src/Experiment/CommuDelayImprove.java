package Experiment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

import Resources.TotalResource;
import Solution.Solution;
import Tools.Format;
import Tools.Formula;
import Tools.Io;
import Tools.ValidationChecking;
import ParetoFront.ParetoFront;
import ParetoFront.ParetoFrontSet;

public class CommuDelayImprove {
	TotalResource tr;
	String ff;
	int nth;
	Solution oldSolution;
	Solution newSolution;
	ArrayList<Solution> newsolutionList=new ArrayList<Solution>();
//	int[] sort;
	public ArrayList<ParetoFront> pfList=new ArrayList<ParetoFront>();
	int count=0;
//	double taskpercent;
	double allocationpercent;
	String str="CommuDelayImprove";
	public long ECtime=0;
	ParetoFrontSet communicationPFset=new ParetoFrontSet(ff,nth);
	Table<Integer,Integer,Double> table;
	
	public CommuDelayImprove(String ff, int nth,Solution oldSolution,double allocationpercent,ArrayList<ParetoFront> communicationlist,Table<Integer,Integer,Double> table) {//
		
		this.ff=ff;
		this.nth=nth;
		this.oldSolution = oldSolution;
		this.table=table;
//		this.sort=sort;
		this.allocationpercent=allocationpercent;
		TotalResource tr=new TotalResource(ff,nth);
		this.tr=tr;
		newSolution=new Solution(oldSolution.getSolutionF(),oldSolution.getSolutionC(),oldSolution.getSolutionM(),oldSolution.getSolutionFC(),oldSolution.getTotalDelay(),oldSolution.getTotalPowerConsumption());
		ParetoFront pf=new ParetoFront(oldSolution.getTotalDelay(),oldSolution.getTotalPowerConsumption());
		pf.setContributor(str);
		pf.setSolution(oldSolution.copy());
		pfList.add(pf);
		newsolutionList.add(oldSolution.copy());
		communicationPFset.setSet(communicationlist);
	}
	
	
	
	public long getECtime() {
		return ECtime;
	}



	public void runCommu() {
		
		Random r=new Random();
		int fNum=oldSolution.getSolutionF().size();
		int cNum=oldSolution.getSolutionC().size();
		double[][] d1=new double[tr.getdM().getCommuDelayMatrix().length][tr.getdM().getCommuDelayMatrix()[0].length];
		boolean[][] flag1=new boolean[tr.getdM().getCommuDelayMatrix().length][tr.getdM().getCommuDelayMatrix()[0].length];
		for(int i=0;i<tr.getdM().getCommuDelayMatrix().length;i++) {
			for(int j=0;j<tr.getdM().getCommuDelayMatrix()[0].length;j++) {
				d1[i][j]=tr.getdM().getCommuDelay(i, j);
				flag1[i][j]=true;
			}
		}
		long start = System.currentTimeMillis();
		for(int i=0;i<fNum;i++) {
			int v=r.nextInt(d1[0].length);
	//		while() {
				Arrays.sort(d1[i]);
				for(int j=0;j<d1[0].length;j++) {
					
					while(d1[i][j]!=tr.getdM().getCommuDelay(i, v)||flag1[i][v]==false) {//
						v=(v+1)%d1[0].length;
					}
					flag1[i][v]=false;
					if(newSolution.getSolutionFC().get(i).get(v)<tr.getaM().getMaxAllocation(i, v)) {
						while(newSolution.getSolutionFC().get(i).get(v)<tr.getaM().getMaxAllocation(i, v)&& newSolution.getSolutionF().get(i)>0) {
							int diff=0;
							if(newSolution.getSolutionF().get(i)<=10) {
							   diff=newSolution.getSolutionF().get(i);
							}else {
								diff=(int)(newSolution.getSolutionF().get(i)*allocationpercent);
							}
							int diff2=Math.min(tr.getaM().getMaxAllocation(i, v)-newSolution.getSolutionFC().get(i).get(v), tr.getYmax(v)-newSolution.getSolutionC().get(v));
							if(diff2==0) {
								break;
							}
							newSolution.getSolutionF().set(i, Math.max(newSolution.getSolutionF().get(i)-diff, newSolution.getSolutionF().get(i)-diff2));
							newSolution.getSolutionFC().get(i).set(v, Math.min(newSolution.getSolutionFC().get(i).get(v)+diff,newSolution.getSolutionFC().get(i).get(v)+diff2));
							newSolution.setSolutionC(GenerateC());
							newSolution.setSolutionM(GenerateM());
							
							if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), newSolution.getSolutionF(), newSolution.getSolutionC(), newSolution.getSolutionFC())&&
									ValidationChecking.fogChecking(tr.getFogset(), newSolution.getSolutionF())&&
									ValidationChecking.cloudChecking(tr.getCloudset(), newSolution.getSolutionC(), newSolution.getSolutionM())&&
									ValidationChecking.communicationChecking(newSolution.getSolutionFC(), tr.getaM())) {
								Formula.ComputeSolution(ff, nth, newSolution,table);
								ECtime+=Formula.ECtime;
								Formula.PrintResult(ff, nth, newSolution);
								count++;
								boolean flag=true;
								ArrayList<Solution> deletes=new ArrayList<Solution>();
								ArrayList<ParetoFront> deletepf=new ArrayList<ParetoFront>();
								Iterator<ParetoFront> it =pfList.iterator();
						        while (it.hasNext()) {
						        	ParetoFront temp=it.next();
						        	if((temp.getTotalDelay()>=newSolution.getTotalDelay())&&(temp.getTotalPowerConsumption()>=newSolution.getTotalPowerConsumption())) {
						        		deletepf.add(temp);//(new ParetoFront(temp.getTotalDelay(),temp.getTotalPowerConsumption()));
						        		Iterator<Solution> ut=newsolutionList.iterator();
						        		while(ut.hasNext()) {
						        			Solution solution=ut.next();
						        			if(solution.getTotalDelay()==temp.getTotalDelay()&&solution.getTotalPowerConsumption()==temp.getTotalPowerConsumption()) {
						        				deletes.add(solution);//(new Solution(solution.getSolutionF(),solution.getSolutionC(),solution.getSolutionM(),solution.getSolutionFC(),solution.getTotalDelay(),solution.getTotalPowerConsumption()));
						        			}
						        		}
						        	}else if((temp.getTotalDelay()<=newSolution.getTotalDelay())&&(temp.getTotalPowerConsumption()<=newSolution.getTotalPowerConsumption())){
						        		flag=false;
						        	}else {

						        		}
						        	}
						        if(flag==true) {
					        		ParetoFront newpf=new ParetoFront(newSolution.getTotalDelay(),newSolution.getTotalPowerConsumption());
					        		newpf.setContributor(str);
					        		newpf.setSolution(newSolution.copy());
					        		if(!pfList.contains(newpf)) {
					        			pfList.add(newpf);
					        			newsolutionList.add(newSolution.copy());
					        	}
					        		if(deletepf.size()!=0) {
					        			for(int s=0;s<deletepf.size();s++) {
					        				pfList.remove(deletepf.get(s));
//					        				deletepf.remove(j);
					        			}
					        		}
					        		if(deletes.size()!=0) {
					        			for(int s=0;s<deletes.size();s++) {
					        				newsolutionList.remove(deletes.get(s));
//					        				deletes.remove(j);
					        			}
					        		}
					        		deletes=null;
					        		deletepf=null;
						        }
							}
							if(System.currentTimeMillis()-start>300000) break;
						} 
					}
					if(newSolution.getSolutionF().get(i)==0) 
						break;
				}
	//		}
		}
		ParetoFrontSet anotherset=new ParetoFrontSet(ff,nth);
		anotherset.setSet(pfList);
		anotherset.mergeWithSet(communicationPFset);	
		this.pfList=anotherset.getSet();
}	
	
	//����cloud��
		public ArrayList<Integer> GenerateC(){
			ArrayList<Integer> a=new ArrayList<Integer>();
			ArrayList<ArrayList<Integer>> lamda=newSolution.getSolutionFC();
			for(int i=0;i<lamda.get(0).size();i++) {
				int sum=0;
				for(int j=0;j<lamda.size();j++) {
					sum+=lamda.get(j).get(i);
				}
				a.add(sum);
			}
			return a;	
		}
		
		//���ɻ�������
		public ArrayList<Integer> GenerateM(){
			ArrayList<Integer> a=new ArrayList<Integer>();
			ArrayList<Integer> y=newSolution.getSolutionC();
			for(int i=0;i<y.size();i++) {
				if(y.get(i)!=0) {
					float v=(float)(y.get(i)/tr.getCloudset().getCloud(i).getFrequency())+1;
//					System.out.println(v);
				        	a.add((int)v);
				}else {
					a.add(0);
				}
				
			}
			return a;	
		}
		

		
		
		public void print() throws IOException {
//			System.out.println();
			Iterator<ParetoFront> it=pfList.iterator();
			while(it.hasNext()) {
				ParetoFront temp=it.next();
				System.out.println(temp);
				String[][] str= {{Double.toString(temp.getTotalDelay()),Format.formatbig(temp.getTotalPowerConsumption())}};
//				String str2=;
				Io.WriteFile(Io.location2,"ParetoFrontcommu_"+ff, str);
				temp.getSolution().PrintSolution();
			}
			Io.WriteFile(Io.location2, "ParetoFrontcommu_"+ff, Io.separa);
			Iterator<ParetoFront> it2=pfList.iterator();
			while(it2.hasNext()) {
				ParetoFront temp=it2.next();
//				temp.computArpd(GetBestDelay(), GetWorstDelay(),GetBestConsumption(),GetWorstConsumption());
				String[][] str= {{String.format("%.6f", temp.getDelay_arpd()),String.format("%.6f", temp.getPowerconsumption_arpd())}};
				Io.WriteFile(Io.location2,"ParetoFrontcommu_"+ff, str);
				
			}
			Io.WriteFile(Io.location2, "ParetoFrontcommu_"+ff, Io.separa);
		
			System.out.println(pfList.size());
			

		}
		
		
		
		public void setPfList(ArrayList<ParetoFront> pfList) {
			ArrayList<ParetoFront> pfList1=new ArrayList<ParetoFront>();
			for(int i=0;i<pfList.size();i++) {
				ParetoFront pf=pfList.get(i).copy();
				pfList1.add(pf);
			}
			this.pfList = pfList1;
		}

		public static void main(String[] args) throws IOException {
			
		}
}
