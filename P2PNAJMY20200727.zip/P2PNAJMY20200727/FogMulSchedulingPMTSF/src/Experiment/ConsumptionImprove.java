package Experiment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

import Resources.TotalResource;
import Solution.Solution;
import Tools.Format;
import Tools.Formula;
import Tools.Io;
import Tools.ValidationChecking;
import ParetoFront.ParetoFront;
import ParetoFront.ParetoFrontSet;

public class ConsumptionImprove {
	TotalResource tr;
	String ff;
	int nth;
	Solution oldSolution;
	Solution newSolution;
	ArrayList<Solution> newsolutionList=new ArrayList<Solution>();
	int[] sort;
	public ArrayList<ParetoFront> pfList=new ArrayList<ParetoFront>();
	int count=0;
	double taskpercent;
	double allocationpercent;
	String str="ConsumptionImprove";
	public long ECtime=0;
	ParetoFrontSet consumptionPFset=new ParetoFrontSet(ff,nth);
	Table<Integer,Integer,Double> table;
	
	public ConsumptionImprove(String ff, int nth,Solution oldSolution,int[] sort,double taskpercent,double allocationpercent,ArrayList<ParetoFront> consumptionlist,Table<Integer,Integer,Double> table) {//
		super();
		this.ff=ff;
		this.nth=nth;
		this.table=table;
		this.oldSolution = oldSolution;
		this.sort=sort;
		this.taskpercent=taskpercent;
		this.allocationpercent=allocationpercent;
		TotalResource tr=new TotalResource(ff,nth);
		this.tr=tr;
		newSolution=new Solution(oldSolution.getSolutionF(),oldSolution.getSolutionC(),oldSolution.getSolutionM(),oldSolution.getSolutionFC(),oldSolution.getTotalDelay(),oldSolution.getTotalPowerConsumption());
		ParetoFront pf=new ParetoFront(oldSolution.getTotalDelay(),oldSolution.getTotalPowerConsumption());
		pf.setContributor(str);
		pf.setSolution(newSolution.copy());
		pfList.add(pf);
		newsolutionList.add(newSolution.copy());
		consumptionPFset.setSet(consumptionlist);
	}

	public void runconsum() {
		int fNum=oldSolution.getSolutionF().size();
		int cNum=oldSolution.getSolutionC().size();
		Random r=new Random();
		HashSet<Integer> set=new HashSet<Integer>();
		for(int i=0;i<fNum;i++) {
			set.add(i);
		}
		int v=0;
		//�ӵȼ��͵Ŀ�ʼ
		for(int i=0;i<oldSolution.getSolutionC().size()-1;i++) {
			if((oldSolution.getSolutionC().get(sort[i])!=0)&&(oldSolution.getSolutionC().get(sort[i+1])==0)) {//==tr.getYmax(sort[i]))&&(oldSolution.getSolutionC().get(sort[i+1])!=tr.getYmax(sort[i+1]))) {
				v=i;
				break;
			}
			v=oldSolution.getSolutionC().size()-1;
		}
//		while(set.size()!=0) {
//			int ran=r.nextInt(fNum);
//			if(set.contains(ran)) {
//				set.remove(ran);
//				
//			}
//		}
		long start = System.currentTimeMillis();
		for(int i=0;i<fNum;i++) {
			int v1=v;
			while(newSolution.getSolutionF().get(i)<(int)(tr.getFogset().getFog(i).getMaxTaskNum()*taskpercent)) {
				if(newSolution.getSolutionFC().get(i).get(sort[v1])==0) {
					v1--;
				}
				if(v1<0) {
					break;
				}
				int diff=0;
				if(newSolution.getSolutionFC().get(i).get(sort[v1])<=10) {
				   diff=newSolution.getSolutionFC().get(i).get(sort[v1]);
				}else {
					diff=(int)(newSolution.getSolutionFC().get(i).get(sort[v1])*allocationpercent);
				}
				int diff2=(int)(tr.getFogset().getFog(i).getMaxTaskNum()*taskpercent)-newSolution.getSolutionF().get(i);
				if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), newSolution.getSolutionF(), newSolution.getSolutionC(), newSolution.getSolutionFC())&&
						ValidationChecking.fogChecking(tr.getFogset(), newSolution.getSolutionF())&&
						ValidationChecking.cloudChecking(tr.getCloudset(), newSolution.getSolutionC(), newSolution.getSolutionM())&&
						ValidationChecking.communicationChecking(newSolution.getSolutionFC(), tr.getaM())) {
				newSolution.getSolutionF().set(i, Math.min(newSolution.getSolutionF().get(i)+diff, newSolution.getSolutionF().get(i)+diff2));
				newSolution.getSolutionFC().get(i).set(sort[v1], Math.max(newSolution.getSolutionFC().get(i).get(sort[v1])-diff,newSolution.getSolutionFC().get(i).get(sort[v1])-diff2));
				newSolution.setSolutionC(GenerateC());
				newSolution.setSolutionM(GenerateM());
				Formula.ComputeSolution(ff, nth, newSolution,table);
				ECtime+=Formula.ECtime;
				Formula.PrintResult(ff, nth, newSolution);
				if(newSolution.getSolutionF().get(i)>tr.getFogset().getFog(i).getMaxTaskNum()) {
					break;
				}
				count++;
				boolean flag=true;
				ArrayList<Solution> deletes=new ArrayList<Solution>();
				ArrayList<ParetoFront> deletepf=new ArrayList<ParetoFront>();
				Iterator<ParetoFront> it =pfList.iterator();
		        while (it.hasNext()) {
		        	ParetoFront temp=it.next();
		        	if((temp.getTotalDelay()>=newSolution.getTotalDelay())&&(temp.getTotalPowerConsumption()>=newSolution.getTotalPowerConsumption())) {
		        		deletepf.add(temp);//(new ParetoFront(temp.getTotalDelay(),temp.getTotalPowerConsumption()));
		        		Iterator<Solution> ut=newsolutionList.iterator();
		        		while(ut.hasNext()) {
		        			Solution solution=ut.next();
		        			if(solution.getTotalDelay()==temp.getTotalDelay()&&solution.getTotalPowerConsumption()==temp.getTotalPowerConsumption()) {
		        				deletes.add(solution);//(new Solution(solution.getSolutionF(),solution.getSolutionC(),solution.getSolutionM(),solution.getSolutionFC(),solution.getTotalDelay(),solution.getTotalPowerConsumption()));
		        			}
		        		}
		        	}else if((temp.getTotalDelay()<=newSolution.getTotalDelay())&&(temp.getTotalPowerConsumption()<=newSolution.getTotalPowerConsumption())){
		        		flag=false;
		        	}else {

		        		}
		        	}
		        if(flag==true) {
	        		ParetoFront newpf=new ParetoFront(newSolution.getTotalDelay(),newSolution.getTotalPowerConsumption());
	        		newpf.setContributor(str);
	        		newpf.setSolution(newSolution.copy());
	        		if(!pfList.contains(newpf)) {
	        			pfList.add(newpf);
	        			newsolutionList.add(newSolution.copy());
	        	}
	        		if(deletepf.size()!=0) {
	        			for(int j=0;j<deletepf.size();j++) {
	        				pfList.remove(deletepf.get(j));
//	        				deletepf.remove(j);
	        			}
	        		}
	        		if(deletes.size()!=0) {
	        			for(int j=0;j<deletes.size();j++) {
	        				newsolutionList.remove(deletes.get(j));
//	        				deletes.remove(j);
	        			}
	        		}
	        		deletes=null;
	        		deletepf=null; 
		        }
		        
		        }
				if(System.currentTimeMillis()-start>300000) break;
			}
			
			if(newSolution.getSolutionF().get(i)>tr.getFogset().getFog(i).getMaxTaskNum()) {
				int m=newsolutionList.size();
				newSolution=newsolutionList.get(m-1).copy();
			}
			if(System.currentTimeMillis()-start>300000) break;
		}
		
		ParetoFrontSet anotherset=new ParetoFrontSet(ff,nth);
		anotherset.setSet(pfList);
		anotherset.mergeWithSet(consumptionPFset);;	
		this.pfList=anotherset.getSet();
	}
	
	//����cloud��
	public ArrayList<Integer> GenerateC(){
		ArrayList<Integer> a=new ArrayList<Integer>();
		ArrayList<ArrayList<Integer>> lamda=newSolution.getSolutionFC();
		for(int i=0;i<lamda.get(0).size();i++) {
			int sum=0;
			for(int j=0;j<lamda.size();j++) {
				sum+=lamda.get(j).get(i);
			}
			a.add(sum);
		}
		return a;	
	}
	
	//���ɻ�������
	public ArrayList<Integer> GenerateM(){
		ArrayList<Integer> a=new ArrayList<Integer>();
		ArrayList<Integer> y=newSolution.getSolutionC();
		for(int i=0;i<y.size();i++) {
			if(y.get(i)!=0) {
				float v=(float)(y.get(i)/tr.getCloudset().getCloud(i).getFrequency())+1;
//				System.out.println(v);
			        	a.add((int)v);
			}else {
				a.add(0);
			}
			
		}
		return a;	
	}
	
	public void print() throws IOException {

		Iterator<ParetoFront> it=pfList.iterator();
		while(it.hasNext()) {
			ParetoFront temp=it.next();
			System.out.println(temp);
			String[][] str= {{Double.toString(temp.getTotalDelay()),Format.formatbig(temp.getTotalPowerConsumption())}};
			Io.WriteFile(Io.location2,"ParetoFront_"+ff, str);
			temp.getSolution().PrintSolution();
		}
		Io.WriteFile(Io.location2, "ParetoFront_"+ff, Io.separa);
		Iterator<ParetoFront> it2=pfList.iterator();
		while(it2.hasNext()) {
			ParetoFront temp=it2.next();
//			temp.computArpd(GetBestDelay(), GetWorstDelay(),GetBestConsumption(),GetWorstConsumption());
			String[][] str= {{String.format("%.6f", temp.getDelay_arpd()),String.format("%.6f", temp.getPowerconsumption_arpd())}};
			Io.WriteFile(Io.location2,"ParetoFrontConsum_"+ff, str);
			
		}
		Io.WriteFile(Io.location2, "ParetoFrontConsum_"+ff, Io.separa);
		
		System.out.println(pfList.size());
		

	}
	

	
	public void setPfList(ArrayList<ParetoFront> pfList) {
		ArrayList<ParetoFront> pfList1=new ArrayList<ParetoFront>();
		for(int i=0;i<pfList.size();i++) {
			ParetoFront pf=pfList.get(i).copy();
			pfList1.add(pf);
		}
		this.pfList = pfList1;
	}
	public static void main(String[] args) throws IOException {
		String ff="9_6_4~6";
		int nth=1;
		double taskpercent=0.8;
		Table<Integer,Integer,Double> table=HashBasedTable.create();
		double allocationpercent=0.1;
		Solution initial;
		ConsumptionImprove	improve1=null;
		long consumtime=0;
			ConsumptionGenerateIniSolution gs=new ConsumptionGenerateIniSolution(ff,nth,table);
			gs.run();
			if(gs.solutionList.size()!=0){
				initial=gs.solutionList.get(0);
				Iterator<Solution> it=gs.solutionList.iterator();
	    		while(it.hasNext()) {
	    			Solution temp=it.next();
	    			if(temp.getTotalPowerConsumption()<initial.getTotalPowerConsumption()) {
	    				initial=temp;
	    			}
	    		}
	    		long start1 = System.currentTimeMillis();
	    		improve1=new ConsumptionImprove(ff,nth,initial,gs.sort,taskpercent,allocationpercent,gs.consumptionlist,table);
	    		improve1.runconsum();
	    		consumtime=System.currentTimeMillis()-start1-improve1.ECtime;
			}
		
//		ConsumptionGenerateIniSolution gs=new ConsumptionGenerateIniSolution(ff,nth);
//		gs.run();
//		Solution initial;
//		if(gs.solutionList.size()!=0) {
//			initial=gs.solutionList.get(0);
//			Iterator<Solution> it=gs.solutionList.iterator();
//			while(it.hasNext()) {
//				Solution temp=it.next();
//				if(temp.getTotalDelay()<initial.getTotalDelay()) {
//					initial=temp;
//				}
//			}
//			ConsumptionImprove	improve1=new ConsumptionImprove(ff,nth,initial,gs.sort,taskpercent,allocationpercent);
//			improve1.runconsum();
//			improve1.print();
//		}else {
//			ConsumptionGenerateIniSolution2 gs2=new ConsumptionGenerateIniSolution2(ff,nth);
//			gs2.run();
//			if(gs2.solutionList.size()!=0){
//				initial=gs2.solutionList.get(0);
//				Iterator<Solution> it=gs2.solutionList.iterator();
//	    		while(it.hasNext()) {
//	    			Solution temp=it.next();
//	    			if(temp.getTotalPowerConsumption()<initial.getTotalPowerConsumption()) {
//	    				initial=temp;
//	    			}
//	    		}
//	    		ConsumptionImprove improve1=new ConsumptionImprove(ff,nth,initial,gs.sort,taskpercent,allocationpercent);
//	    		improve1.runconsum();
//	    		improve1.print();
//			}else {
//				System.out.println("�޽⣡");
//			}
/*
 *for(int i=1;i<=10;i++){
 *
 * for(int j=1;j<=6;j++){
 * 	for(int v=1;v<=;v++){
 * 	String ff=i+"_"+j+"_"+v;
 *  int nth=1;
 *  
 *  
 *  
 *  
 *  
 *  
 *  
 *  
 *  nth++;
 * }
 *}
 */
		
		
	}
}

