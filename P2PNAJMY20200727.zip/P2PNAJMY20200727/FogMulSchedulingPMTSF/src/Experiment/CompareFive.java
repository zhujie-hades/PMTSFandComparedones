package Experiment;

import java.io.IOException;
import com.google.common.collect.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import ParetoFront.ParetoFront;
import ParetoFront.ParetoFrontSet;
import Solution.Solution;
import Tools.Io;

public class CompareFive {
	CommuDelayImprove commuimprove;
	ConsumptionImprove consumpimprove;
	SimulateAnneal saimprove;
	PMTSF pimprove;
	VND vndimprove;
	ParetoFrontSet communicationset;
	ParetoFrontSet consumptionset;
	ParetoFrontSet saset;
	ParetoFrontSet vnsset;
	ParetoFrontSet HSset;
	ParetoFrontSet Allset;
	ParetoFrontSet Rset;
	String ff;
	int nth;
	public CompareFive(String ff,int nth,CommuDelayImprove commuimprove, ConsumptionImprove consumpimprove,SimulateAnneal saimprove,PMTSF pimprove,VND vndimprove) throws IOException {//
		super();
		this.consumpimprove = consumpimprove;
		this.commuimprove = commuimprove;
		this.saimprove=saimprove;
		this.pimprove=pimprove;
		this.vndimprove=vndimprove;
		this.communicationset= new ParetoFrontSet(ff,nth);
		communicationset.setSet(commuimprove.pfList);
		this.consumptionset =new ParetoFrontSet(ff,nth);
		consumptionset.setSet(consumpimprove.pfList);
		this.saset=new ParetoFrontSet(ff,nth);
		saset.setSet(saimprove.pfList.getSet());
		this.vnsset=new ParetoFrontSet(ff,nth);
		vnsset.setSet(pimprove.getPfList().getSet());
		this.HSset=new ParetoFrontSet(ff,nth);
		HSset.setSet(vndimprove.pfList.getSet());
		this.Rset= new ParetoFrontSet(ff,nth);
		Rset.setSet(commuimprove.pfList);
		Rset.mergeWithSet(consumptionset);
		Rset.mergeWithSet(saset);
		Rset.mergeWithSet(vnsset);
		Rset.mergeWithSet(HSset);
		this.Allset= new ParetoFrontSet(ff,nth);
		Allset.setSet(consumpimprove.pfList);
		Allset.setSet(commuimprove.pfList);
		Allset.setSet(saimprove.getPfList().getSet());
		Allset.setSet(pimprove.getPfList().getSet());
		Allset.setSet(vndimprove.pfList.getSet());
		communicationset.computeARPD(Allset);
		consumptionset.computeARPD(Allset);
		saset.computeARPD(Allset);
		vnsset.computeARPD(Allset);
		HSset.computeARPD(Allset);
		this.commuimprove.setPfList(communicationset.getSet());
		this.consumpimprove.setPfList(consumptionset.getSet());
		this.saimprove.setPfList(saset);
		this.pimprove.setPfList(vnsset);
		this.vndimprove.setPfList(HSset);
		Rset.computeARPD(Allset);
		this.ff=ff;
		this.nth=nth;
	}
	
	
	
	public ParetoFrontSet getRset() {
		return Rset;
	}

	public void print(long commutime,long consumtime,long satime,long ptime,long vndtime) throws IOException {
		String[] strs= {"CommuDelayImprove","ConsumptionImprove","SAImprove","PMTSFImprove","VNDImprove"};
		String[] temp=ff.split("_");
		for(int j=0;j<strs.length;j++) {
			String[][] string=new String[1][11];
			string[0][0]=ff+"_"+nth;
			for(int i=0;i<temp.length;i++) {
				string[0][i+1]=temp[i];
			}
			//��stringbuffer����Ӹ���ָ��ֵ
			string[0][4]=strs[j];
			if(strs[j].equals(commuimprove.str)) {
				string[0][5]=String.format("%.3f",communicationset.AverageQuality());
				string[0][6]=String.format("%.3f",communicationset.MaximumSpread(Rset));
				string[0][7]=String.format("%.3f",communicationset.distanceMetricAvg(Rset));
				string[0][8]=String.format("%.3f",communicationset.distanceMetricMax(Rset));
				string[0][9]=Long.toString(commutime);
				string[0][10]=null;
			}else if(strs[j].equals(consumpimprove.str)){
				string[0][5]=String.format("%.3f",consumptionset.AverageQuality());
				string[0][6]=String.format("%.3f",consumptionset.MaximumSpread(Rset));
				string[0][7]=String.format("%.3f",consumptionset.distanceMetricAvg(Rset));
				string[0][8]=String.format("%.3f",consumptionset.distanceMetricMax(Rset));
				string[0][9]=Long.toString(consumtime);
				string[0][10]=null;
			}else if(strs[j].equals(saimprove.str)) {
				string[0][5]=String.format("%.3f",saset.AverageQuality());
				string[0][6]=String.format("%.3f",saset.MaximumSpread(Rset));
				string[0][7]=String.format("%.3f",saset.distanceMetricAvg(Rset));
				string[0][8]=String.format("%.3f",saset.distanceMetricMax(Rset));
				string[0][9]=Long.toString(satime);
				string[0][10]=null;
			}else if(strs[j].equals(pimprove.str)) {
				string[0][5]=String.format("%.3f",vnsset.AverageQuality());
				string[0][6]=String.format("%.3f",vnsset.MaximumSpread(Rset));
				string[0][7]=String.format("%.3f",vnsset.distanceMetricAvg(Rset));
				string[0][8]=String.format("%.3f",vnsset.distanceMetricMax(Rset));
				string[0][9]=Long.toString(ptime);
				string[0][10]=Integer.toString(pimprove.ifkxi);
			}else {
				string[0][5]=String.format("%.3f",HSset.AverageQuality());
				string[0][6]=String.format("%.3f",HSset.MaximumSpread(Rset));
				string[0][7]=String.format("%.3f",HSset.distanceMetricAvg(Rset));
				string[0][8]=String.format("%.3f",HSset.distanceMetricMax(Rset));
				string[0][9]=Long.toString(vndtime);
				string[0][10]=null;
			}
			
			Io.WriteFile(Io.location3, "RESULTSAVNDHS", string);
		}
		
	}
	
	

	






	public static void main(String[] args) throws IOException {	
		int[] str= {0,2,4,6};
		for(int r=2;r<3;r++) {
			for(int p=5;p<11;p++) {
				for(int q=p-4;q<7;q++) {//p-4
					int s=str[r]+2;
					int n=p;
					if(q<1) {
						q=1;
					}
					int m=q;
					String ff=n+"_"+m+"_"+str[r]+"~"+s;
					for(int t=4;t<=4;t++) {//Io.getNth(ff)
						int nth=t;
						Table<Integer,Integer,Double> table=HashBasedTable.create();
						table.put(100, 0, 0.0);
						//delay
						double allocationpercent=0.1;
						CommuDelayGenerateIniSolution gscommu=new CommuDelayGenerateIniSolution(ff,nth,table);
						gscommu.run();
						if(gscommu.solutionList.size()==0) {
							break;
						}
						long start = System.currentTimeMillis();
						CommuDelayImprove improve=new CommuDelayImprove(ff,nth,gscommu.GetInitialS(),allocationpercent,gscommu.communicationlist,table);
						improve.runCommu();
						long commutime=System.currentTimeMillis()-start-improve.getECtime();
						
						//consumption
						double taskpercent=0.8;
						Solution initial;
						ConsumptionImprove	improve1=null;
						long consumtime=0;
							ConsumptionGenerateIniSolution gs=new ConsumptionGenerateIniSolution(ff,nth,table);
							gs.run();
							if(gs.solutionList.size()!=0){
								initial=gs.solutionList.get(0);
								Iterator<Solution> it=gs.solutionList.iterator();
					    		while(it.hasNext()) {
					    			Solution temp=it.next();
					    			if(temp.getTotalPowerConsumption()<initial.getTotalPowerConsumption()) {
					    				initial=temp;
					    			}
					    		}
					    		long start1 = System.currentTimeMillis();
					    		improve1=new ConsumptionImprove(ff,nth,initial,gs.sort,taskpercent,allocationpercent,gs.consumptionlist,table);
					    		improve1.runconsum();
					    		consumtime=System.currentTimeMillis()-start1-improve1.ECtime;
							}else {
								break;
							}
					
						if(improve.pfList.size()==0||improve1.pfList.size()==0) {
							break;
						}
						
						//VND
						long start3 = System.currentTimeMillis();
						VND vndimprove=new VND(ff,nth,improve.pfList,improve1.pfList,table);
						vndimprove.run(start3,3);
						long vndtime=System.currentTimeMillis()-start3-vndimprove.ECtime;
						
						
						//PMTSF
						long start2 = System.currentTimeMillis();
						PMTSF pimprove=new PMTSF(ff,nth,improve.pfList,improve1.pfList,table);
						pimprove.run(start2,3);
						long ptime=System.currentTimeMillis()-start2-pimprove.ECtime;
						
						//SA
						long start4 = System.currentTimeMillis();
						SimulateAnneal saimprove=new SimulateAnneal(ff,nth,improve.pfList,improve1.pfList,table);
						saimprove.run(start4);
						long satime=System.currentTimeMillis()-start4-saimprove.ECtime;
						
						//�����㷨�Ƚ�
						CompareFive compare=new CompareFive(ff,nth,improve,improve1,saimprove,pimprove,vndimprove);
						compare.getRset().print();
						compare.print(commutime,consumtime,satime,ptime,vndtime);
						table=null;
					}
				}
			}
		}
	}
	
}
