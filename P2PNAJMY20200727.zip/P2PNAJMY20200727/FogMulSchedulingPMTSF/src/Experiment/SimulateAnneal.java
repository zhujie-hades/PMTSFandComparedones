package Experiment;

import java.util.ArrayList;
import java.util.Random;

import com.google.common.collect.Table;

import ParetoFront.ParetoFront;
import ParetoFront.ParetoFrontSet;
import Resources.TotalResource;
import Solution.Solution;
import Tools.Formula;
import Tools.ValidationChecking;

public class SimulateAnneal {//Լ���������¶ȣ���ʼ�⣨pf�⣩����  ���̣�news=�任olds��ifpftrue��olds=news elseif����һ�����ʽ���olds=news else��pf++
	int T=100;
	double rate=0.9;
	ParetoFrontSet communicationset;
	ParetoFrontSet consumptionset;
	ParetoFrontSet pfList;
	String str="SAImprove";
	String ff;
	int nth;
	TotalResource tr;
	public long ECtime=0;
	Table<Integer,Integer,Double> table;
	
	public SimulateAnneal(String ff,int nth, ArrayList<ParetoFront> communicationlist,  ArrayList<ParetoFront> consumptionlist,Table<Integer,Integer,Double> table) {
		this.ff=ff;
		this.nth=nth;
		this.table=table;
		this.communicationset = new ParetoFrontSet(ff,nth);
		communicationset.setSet(communicationlist);
		this.consumptionset = new ParetoFrontSet(ff,nth);
		consumptionset.setSet(consumptionlist);
		TotalResource tr=new TotalResource(ff,nth);
		this.tr=tr;
		pfList=new ParetoFrontSet(ff,nth);
		pfList.getSet().add(new ParetoFront(Double.MAX_VALUE,Double.MAX_VALUE));
		pfList.mergeWithSet(consumptionset);
		pfList.mergeWithSet(communicationset);	
	}
	
	public ParetoFrontSet getPfList() {
		return pfList;
	}

	public void setPfList(ParetoFrontSet pfList) {
		this.pfList = pfList;
	}
	
//	public boolean ifpfTrue() {
//		boolean flag1=false;
//		for(int i=0;i<pfList.getSet().size();i++) {
//			if(pfList.getSet().get(i).getFlag()==true) {
//				flag1=true;
//				break;
//			}
//		}
//		return flag1;
//	}
	
	public void run(long start) {
		ParetoFrontSet species=new ParetoFrontSet(ff,nth);//���ɳ�ʼ�⼯
		int num=pfList.getSet().size();
		for(int i=0;i<num;i++) {
			species.getSet().add(pfList.getSet().get(i).copy());
		}
		int index=0;
		ParetoFront pf1=species.getSet().get(index++).copy();
		while(T>1&&index<num) {
			ParetoFrontSet changeset=change(pf1);
			pfList.mergeWithSet(changeset);
			boolean flag=false;
			for(int j=0;j<changeset.getSet().size();j++) {//����һϵ�н������ŵĽ�
				if(changeset.getSet().get(j).getTotalDelay()<=pf1.getTotalDelay()&&changeset.getSet().get(j).getTotalPowerConsumption()<=pf1.getTotalPowerConsumption()) {
					pf1=changeset.getSet().get(j).copy();	
					flag=true;
					break;
				}
			}
			if(flag==false) {
				int j;
				for(j=0;j<changeset.getSet().size();j++) {
				if(Math.exp(distance(pf1,changeset.getSet().get(j))/T)>Math.random()) {
					pf1=changeset.getSet().get(j).copy();
					break;
				}
				if(j>=changeset.getSet().size()) {
					pf1=species.getSet().get(index++).copy();
				}
				}
			}
			T*=rate;
			if(System.currentTimeMillis()-start-ECtime>900) break;
			changeset=null;
		}
	}
	
	public double distance(ParetoFront pf1,ParetoFront pf2) {
		double b=Math.pow(pf1.getTotalPowerConsumption()-pf2.getTotalPowerConsumption(), 2);
		double c=Math.pow(pf1.getTotalDelay()-pf2.getTotalDelay(), 2);
		return b+c;
		
	}
	
	
	//�ܽ�������������destination����
		public ArrayList<Integer> receptindex(Solution solution,int i){
			ArrayList<Integer> a=new ArrayList<Integer>();
			int fvalue=solution.getSolutionF().get(i);
			if(fvalue<(int)(tr.getFogset().getFog(i).getMaxTaskNum()*0.8)) {
				a.add(tr.getCloudset().getcNum());
			}
			for(int p=0;p<tr.getCloudset().getcNum();p++) {
				if(solution.getSolutionFC().get(i).get(p)<tr.getaM().getMaxAllocation(i, p)) {
					a.add(p);
				}
			}
			return a;
		}
		
		public ParetoFrontSet change(ParetoFront pf1) {
		ParetoFrontSet neighborset=new ParetoFrontSet(ff,nth);
		int fNum=pf1.getSolution().getSolutionF().size();
		int cNum=pf1.getSolution().getSolutionC().size();
		pf1.getSolution().PrintSolution();
		int BW;
		Random rand=new Random();
		for(int j=0;j<fNum;j++) {		
//			ArrayList<Integer> receptset=receptindex(pf1.getSolution(),i);
			for(int i=0;i<=cNum;i++) {
//				ParetoFront pf=pf1.copy();
				Solution s1=pf1.getSolution().copy();
				ArrayList<Integer> solutionF=s1.getSolutionF();
				ArrayList<ArrayList<Integer>> solutionFC=s1.getSolutionFC();
				if(i<tr.getCloudset().getcNum()) {//����˼·��һ�м���r*BW����һ�м�ȥʵ�����ӵ�ֵ
					BW=tr.getaM().getMaxAllocation(j, i)/10;
					int newvalue=solutionFC.get(j).get(i)+(int)(rand.nextDouble()*BW);
					if(newvalue>tr.getaM().getMaxAllocation(j, i)) {
						newvalue=tr.getaM().getMaxAllocation(j, i);
					}
					int diff=newvalue-solutionFC.get(j).get(i);
					solutionFC.get(j).set(i, newvalue);
//					for(int v=1;v<=tr.getCloudset().getcNum();v++) {
					int v=rand.nextInt(cNum+1);
						Solution s2=s1.copy();
						ArrayList<Integer> solutionFF=s2.getSolutionF();
						ArrayList<ArrayList<Integer>> solutionFCC=s2.getSolutionFC();
						if((i+v)%(cNum+1)<solutionFCC.get(0).size()) {
							solutionFCC.get(j).set((i+v)%(cNum+1),solutionFCC.get(j).get((i+v)%(cNum+1))-diff);								
							}else {
								solutionFF.set(j, solutionFF.get(j)-diff);
							}
						ParetoFront pfcopy=new ParetoFront(0, 0);
						pfcopy.setSolution(s2);
						GenerateC(pfcopy.getSolution());
						GenerateM(pfcopy.getSolution());
						if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionFC())&&
								ValidationChecking.fogChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF())&&
								ValidationChecking.cloudChecking(tr.getCloudset(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionM())&&
								ValidationChecking.communicationChecking(pfcopy.getSolution().getSolutionFC(), tr.getaM())) {
							pfcopy.getSolution().PrintSolution();
							Formula.ComputeSolution(ff, nth, pfcopy.getSolution(),table);
							ECtime+=Formula.ECtime;
							Formula.PrintResult(ff, nth, pfcopy.getSolution());
							pfcopy.setTotalDelay(pfcopy.getSolution().getTotalDelay());
							pfcopy.setTotalPowerConsumption(pfcopy.getSolution().getTotalPowerConsumption());
							neighborset.getSet().add(pfcopy.copy());
						}
//					}
					
				}else {
					BW=tr.getFogset().getFog(j).getMaxTaskNum()/10;
					int newvalue=solutionF.get(j)+(int)(rand.nextDouble()*BW);
					solutionF.set(j, newvalue);
					int diff=newvalue-solutionF.get(j);
//					for(int v=0;v<cNum;v++) {
					int v=rand.nextInt(cNum);
						Solution s2=s1.copy();
						ArrayList<ArrayList<Integer>> solutionFCC=s2.getSolutionFC();
						solutionFCC.get(j).set(v,solutionFCC.get(j).get(v)-diff);
						ParetoFront pfcopy=new ParetoFront(0, 0);
						pfcopy.setSolution(s2);
						GenerateC(pfcopy.getSolution());
						GenerateM(pfcopy.getSolution());
						if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionFC())&&
								ValidationChecking.fogChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF())&&
								ValidationChecking.cloudChecking(tr.getCloudset(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionM())&&
								ValidationChecking.communicationChecking(pfcopy.getSolution().getSolutionFC(), tr.getaM())) {
							pfcopy.getSolution().PrintSolution();
							Formula.ComputeSolution(ff, nth, pfcopy.getSolution(),table);
							ECtime+=Formula.ECtime;
							Formula.PrintResult(ff, nth, pfcopy.getSolution());
							pfcopy.setTotalDelay(pfcopy.getSolution().getTotalDelay());
							pfcopy.setTotalPowerConsumption(pfcopy.getSolution().getTotalPowerConsumption());
							neighborset.getSet().add(pfcopy.copy());
						}
//					}
	
				}
			}
		}
		return neighborset;
		}
	
	/*public ParetoFrontSet change(ParetoFront pf1) {
		ParetoFrontSet neighborset=new ParetoFrontSet(ff,nth);
		int fNum=pf1.getSolution().getSolutionF().size();
		int cNum=pf1.getSolution().getSolutionC().size();
		pf1.getSolution().PrintSolution();
		for(int i=0;i<fNum;i++) {		
			ArrayList<Integer> receptset=receptindex(pf1.getSolution(),i);
			for(int j=0;j<=cNum;j++) {
//				ParetoFront pf=pf1.copy();
				if(j!=cNum) {
					int value=pf1.getSolution().getSolutionFC().get(i).get(j);
					if(value>0) {
						int d=(int)(value/6);
						int ave=d/2;
						for(int m=0;m<receptset.size();m++) {
							for(int n=m+1;n<receptset.size();n++) {
								ParetoFront pfcopy=pf1.copy();
								if(receptset.get(m)==cNum||receptset.get(n)==cNum) {
									if(receptset.get(m)==cNum) {
										pfcopy.getSolution().getSolutionF().set(i, pfcopy.getSolution().getSolutionF().get(i)+ave);
										pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(n), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(n))+ave);
									}else {
										pfcopy.getSolution().getSolutionF().set(i, pfcopy.getSolution().getSolutionF().get(i)+ave);
										pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(m), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(m))+ave);
									}
								}else {
									pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(m), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(m))+ave);
									pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(n), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(n))+ave);
								}
								pfcopy.getSolution().getSolutionFC().get(i).set(j, value-ave*2);
								GenerateC(pfcopy.getSolution());
								GenerateM(pfcopy.getSolution());
								if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionFC())&&
										ValidationChecking.fogChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF())&&
										ValidationChecking.cloudChecking(tr.getCloudset(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionM())&&
										ValidationChecking.communicationChecking(pfcopy.getSolution().getSolutionFC(), tr.getaM())) {
									pfcopy.getSolution().PrintSolution();
									Formula.ComputeSolution(ff, nth, pfcopy.getSolution(),table);
									ECtime+=Formula.ECtime;
									Formula.PrintResult(ff, nth, pfcopy.getSolution());
									pfcopy.setTotalDelay(pfcopy.getSolution().getTotalDelay());
									pfcopy.setTotalPowerConsumption(pfcopy.getSolution().getTotalPowerConsumption());
									neighborset.getSet().add(pfcopy.copy());
								}
							}
						}
					}
				}else {
					receptset.remove(Integer.valueOf(cNum));
					int value=pf1.getSolution().getSolutionF().get(i);
					if(value>0) {
						int d=(int)(value/6);
						int ave=d/2;
						for(int m=0;m<receptset.size();m++) {
							for(int n=m+1;n<receptset.size();n++) {
								ParetoFront pfcopy=pf1.copy();
								pfcopy.getSolution().getSolutionF().set(i, value-ave*2);								
									pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(m), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(m))+ave);
									pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(n), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(n))+ave);								
									GenerateC(pfcopy.getSolution());
									GenerateM(pfcopy.getSolution());
									if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionFC())&&
											ValidationChecking.fogChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF())&&
											ValidationChecking.cloudChecking(tr.getCloudset(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionM())&&
											ValidationChecking.communicationChecking(pfcopy.getSolution().getSolutionFC(), tr.getaM())) {
										Formula.ComputeSolution(ff, nth, pfcopy.getSolution(),table);
										ECtime+=Formula.ECtime;
										Formula.PrintResult(ff, nth, pfcopy.getSolution());
										pfcopy.setTotalDelay(pfcopy.getSolution().getTotalDelay());
										pfcopy.setTotalPowerConsumption(pfcopy.getSolution().getTotalPowerConsumption());
										neighborset.getSet().add(pfcopy.copy());
									}
							}				
					}
				}
					receptset.add(cNum);	
			}
	
		}
		
	}
		return neighborset;
}	*/
		
		
	
	//����cloud��
		public void GenerateC(Solution solution){
			ArrayList<Integer> a=new ArrayList<Integer>();
			ArrayList<ArrayList<Integer>> lamda=solution.getSolutionFC();
			for(int i=0;i<lamda.get(0).size();i++) {
				int sum=0;
				for(int j=0;j<lamda.size();j++) {
					sum+=lamda.get(j).get(i);
				}
				a.add(sum);
			}
				solution.setSolutionC(a);
		}
		
		//���ɻ�������
		public void GenerateM(Solution solution){
			ArrayList<Integer> a=new ArrayList<Integer>();
			ArrayList<Integer> y=solution.getSolutionC();
			for(int i=0;i<y.size();i++) {
				if(solution.getSolutionC().get(i)!=0) {
					a.add((int)(y.get(i)/tr.getCloudset().getCloud(i).getFrequency())+1);
				}else {
					a.add(0);
				}
				
			}
			solution.setSolutionM(a);
		}
	
}
