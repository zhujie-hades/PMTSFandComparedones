package Experiment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import com.google.common.collect.Table;

import ParetoFront.ParetoFront;
import Resources.TotalResource;
import Solution.Solution;
import Tools.Formula;
import Tools.ValidationChecking;

public class ConsumptionGenerateIniSolution {
	Solution solution;
	TotalResource tr;
	String ff;
	int nth;
	int[][] lamda;
	public int[] sort;
	public ArrayList<Solution> solutionList=new ArrayList<Solution>();
	public ArrayList<ParetoFront> consumptionlist=new ArrayList<ParetoFront>();
	Table<Integer,Integer,Double> table;
	
	public ConsumptionGenerateIniSolution( String ff, int nth,Table<Integer,Integer,Double> table) {
		super();
		this.ff = ff;
		this.nth = nth;
		this.table=table;
		TotalResource tr=new TotalResource(ff,nth);
		this.tr=tr;
		lamda=new int[tr.getFogset().getfNum()][tr.getCloudset().getcNum()];
		sort=new int[tr.getCloudset().getcNum()];
	}


	public void run(){
		//��ʼ����ʼ��
		ArrayList<Integer> sf=new ArrayList<Integer>();
		ArrayList<Integer> sc=new ArrayList<Integer>();
		ArrayList<Integer> sm=new ArrayList<Integer>();
		ArrayList<ArrayList<Integer>> sfc=new ArrayList<ArrayList<Integer>>();
		double td=0;
		double tpc=0;
		for(int i=0;i<tr.getCloudset().getcNum();i++) {
			sc.add(0);
			sm.add(0);
		}
		for(int i=0;i<tr.getFogset().getfNum();i++) {
			sf.add(0);
		}
		
		for(int i=0;i<tr.getFogset().getfNum();i++) {
			ArrayList<Integer> b=new ArrayList<Integer>();
			for(int j=0;j<tr.getCloudset().getcNum();j++) {
				b.add(0);
			}
			sfc.add(b);
		}
		Solution s=new Solution(sf,sc,sm,sfc,td,tpc);
		this.solution=s;
		//̰�ķ����ɳ�ʼ��
//		GenerateC();
//		System.out.println(solution.getSolutionC());
		sortC();
		ArrayList<ArrayList<ArrayList<Integer>>> FClist=new ArrayList<ArrayList<ArrayList<Integer>>>();
		int t=10000;
		while(t>0) {
			ArrayList<ArrayList<Integer>> lamd=GenerateFC();
			solution.setSolutionFC(lamd);
			solution.setSolutionC(GenerateC());
			solution.setSolutionF(GenerateF());
			if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), solution.getSolutionF(),solution.getSolutionC() , solution.getSolutionFC())&&ValidationChecking.fogChecking(tr.getFogset(), GenerateF())) {
				if(!ifcontains(FClist,lamd)) {
					FClist.add(lamd);
				}
			}
			
			t--;
		}
		System.out.println(FClist.size());
		Iterator<ArrayList<ArrayList<Integer>>> it =FClist.iterator();
		long start = System.currentTimeMillis();
        while (it.hasNext()) {
        	ArrayList<ArrayList<Integer>> lamda1=it.next();
        	solution.setSolutionFC(lamda1);
			solution.setSolutionF(GenerateF());
			solution.setSolutionC(GenerateC());
			solution.setSolutionM(GenerateM());
			long time1 = System.currentTimeMillis();
			if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), solution.getSolutionF(), solution.getSolutionC(), solution.getSolutionFC())&&
					ValidationChecking.fogChecking(tr.getFogset(), solution.getSolutionF())&&
					ValidationChecking.cloudChecking(tr.getCloudset(), solution.getSolutionC(), solution.getSolutionM())&&
					ValidationChecking.communicationChecking(solution.getSolutionFC(), tr.getaM())) {
				Formula.ComputeSolution(ff, nth, solution,table);

				Solution temp=new Solution(solution.getSolutionF(),solution.getSolutionC(),solution.getSolutionM(),solution.getSolutionFC(),solution.getTotalDelay(),solution.getTotalPowerConsumption());
				solutionList.add(solution.copy());
				Formula.PrintResult(ff, nth, solution);
				ParetoFront pf=new ParetoFront(solution.getTotalDelay(),solution.getTotalPowerConsumption());
				pf.setSolution(solution.copy());
				consumptionlist.add(pf.copy());
				if(System.currentTimeMillis()-start>300000) break;
			}
			
			//ValidationChecking.cloudChecking(tr.getCloudset(), solution.getSolutionC(), solution.getSolutionM());
			//ValidationChecking.communicationChecking(solution.getSolutionFC(), tr.getaM());
        }
        FClist=null;
//        for(int i=0;i<tr.getCloudset().getcNum();i++) {
//        	System.out.print(tr.getYmax(i)+"\t");
//        }
        
	}
	
	
	public void sortC() {
		int Y=tr.getTotalInput();
		int out=0;
		boolean[] flag=new boolean[tr.getCloudset().getcNum()];
		Arrays.fill(flag, true);
		for(int j=0;j<tr.getCloudset().getcNum();j++) {
			for(int i=0;i<tr.getFogset().getfNum();i++) {
			}
		}
		
		double[] para=new double[tr.getCloudset().getcNum()];
		for(int i=0;i<para.length;i++) {
			double f=tr.getCloudset().getCloud(i).getFrequency();
			double A=tr.getCloudset().getCloud(i).getA();
			int  B=tr.getCloudset().getCloud(i).getB();
			double a=(A*Math.pow(f, 3)+B)/f;
			para[i]=a;
		}
		double[] para1=Arrays.copyOf(para, para.length);
		Arrays.sort(para1);
		for(int j=0;j<para1.length;j++) {
			int v=0;
			while(para1[j]!=para[v]||flag[v]==false) {
				v++;
			}
			sort[j]=v;
			flag[v]=false;
		}
	}

	
	public ArrayList<ArrayList<Integer>> GenerateFC(){
		ArrayList<ArrayList<Integer>> a1=new ArrayList<ArrayList<Integer>>();
			Random r=new Random();
			double[][] d1=new double[tr.getdM().getCommuDelayMatrix().length][tr.getdM().getCommuDelayMatrix()[0].length];
			ArrayList<ArrayList<Integer>> a=new ArrayList<ArrayList<Integer>>();
			int[] outf=new int[tr.getFogset().getfNum()];
			
			Arrays.fill(outf, 0);
			int[] outc=new int[tr.getCloudset().getcNum()];
			Arrays.fill(outc, 0);
			for(int p=0;p<tr.getCloudset().getcNum();p++) {
				int i=sort[p];
				
				HashSet<Integer> number2=new HashSet<Integer>();
				for(int u=0;u<d1.length;u++) {
					number2.add(u);
				}
				while(number2.size()!=0) {
					int j=r.nextInt(d1.length);
					if(number2.contains(j)) {
						number2.remove(j);
						lamda[j][i]=min3(tr.getFogset().getFog(j).getTotalInput()-outf[j],tr.getaM().getMaxAllocation(j, i),tr.getYmax(i)-outc[i]);
						outf[j]+=lamda[j][i];
						outc[i]+=lamda[j][i];
					}
				}
			}	
			for(int i=0;i<lamda.length;i++) {
				ArrayList<Integer> b=new ArrayList<Integer>();
				for(int j=0;j<lamda[0].length;j++) {
					b.add(lamda[i][j]);
				}
				a1.add(b);
			}
			return a1;
	}	
	
	public int min3(int a,int b,int c) {
		int min1=Math.min(a, b);
		int min=Math.min(min1, c);
		return min;
	}
	
	public boolean ifcontains(ArrayList<ArrayList<ArrayList<Integer>>> FClist,ArrayList<ArrayList<Integer>> a) {
		boolean flag=true;
		Iterator<ArrayList<ArrayList<Integer>>> it =FClist.iterator();
		if(FClist.size()==0) {
			flag=false;
		}else {
			flag=false;
			while (it.hasNext()&&flag==false) {
				flag=true;
	        	ArrayList<ArrayList<Integer>> b=it.next();
//	        	System.out.println(b);
	        	for(int i=0;i<a.size();i++) {
	        		for(int j=0;j<a.get(0).size();j++) {
	        			int a1=a.get(i).get(j);
	        			int b1=b.get(i).get(j);
	        			if(a1!=b1) {
	        				flag=false;
	        			}
	        		}
	        	}
	        }
			
		}
        return flag;
        
		
	}
	
	public ArrayList<Integer> GenerateC(){
		ArrayList<Integer> b=new ArrayList<Integer>();
		ArrayList<ArrayList<Integer>> fc=solution.getSolutionFC();
		for(int i=0;i<lamda[0].length;i++) {
			int sum=0;
			for(int j=0;j<lamda.length;j++) {
				sum+=fc.get(j).get(i);
			}
			b.add(sum);
		}
		return b;
	}
	
	public ArrayList<Integer> GenerateF(){
		ArrayList<Integer> b=new ArrayList<Integer>();
		ArrayList<ArrayList<Integer>> fc=solution.getSolutionFC();
		for(int i=0;i<lamda.length;i++) {
			int sum=0;
			for(int j=0;j<lamda[0].length;j++) {
				sum+=fc.get(i).get(j);
			}
			b.add(tr.getFogset().getFog(i).getTotalInput()-sum);
		}
		return b;
	}
	
	//���ɻ�������
		public ArrayList<Integer> GenerateM(){
			ArrayList<Integer> a=new ArrayList<Integer>();
			ArrayList<Integer> y=solution.getSolutionC();
			for(int i=0;i<y.size();i++) {
				if(y.get(i)!=0) {
					a.add((int)(y.get(i)/tr.getCloudset().getCloud(i).getFrequency())+1);
				}else {
					a.add(0);
				}
				
			}
			return a;	
		}
		
		
		public Solution GetInitialS2() {
			Solution initial=solutionList.get(0);
			if(solutionList.size()!=0) {
				Iterator<Solution> it=solutionList.iterator();
				while(it.hasNext()) {
					Solution temp=it.next();
					if(temp.getTotalPowerConsumption()<initial.getTotalPowerConsumption()) {
	    				initial=temp;
	    			}
				}
			}
			return initial;
		}
		
		public ArrayList<Solution> getSolutionList() {
			return solutionList;
		}




		public int[] getSort() {
			return sort;
		}


		public ArrayList<ParetoFront> getConsumptionlist() {
			return consumptionlist;
		}


		public static void main(String[] args) {
//			String ff="5_3_5";
//			int nth=1;
//			String ff="4_6_2~4";
//			int nth=1;
//			ConsumptionGenerateIniSolution gs=new ConsumptionGenerateIniSolution(ff,nth);
//				gs.run();
		}

}
