package Experiment;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import com.google.common.collect.Table;

import ParetoFront.ParetoFront;
import Resources.TotalResource;
import Solution.Solution;
import Tools.Formula;
import Tools.ValidationChecking;

public class CommuDelayGenerateIniSolution {

	Solution solution;
	TotalResource tr;
	String ff;
	int nth;
	public ArrayList<Solution> solutionList=new ArrayList<Solution>();
	public ArrayList<ParetoFront> communicationlist=new ArrayList<ParetoFront>();
	Table<Integer,Integer,Double> table;
	
	public CommuDelayGenerateIniSolution(String ff, int nth, Table<Integer,Integer,Double> table) {
		super();
		this.ff = ff;
		this.nth = nth;
		TotalResource tr=new TotalResource(ff,nth);
		this.tr=tr;
		this.table=table;
	}

	public void run(){
		//��ʼ����ʼ��
		ArrayList<Integer> sf=new ArrayList<Integer>();
		ArrayList<Integer> sc=new ArrayList<Integer>();
		ArrayList<Integer> sm=new ArrayList<Integer>();
		ArrayList<ArrayList<Integer>> sfc=new ArrayList<ArrayList<Integer>>();
		double td=0;
		double tpc=0;
		for(int i=0;i<tr.getCloudset().getcNum();i++) {
			sc.add(0);
			sm.add(0);
		}
		for(int i=0;i<tr.getFogset().getfNum();i++) {
			sf.add(0);
		}
		
		for(int i=0;i<tr.getFogset().getfNum();i++) {
			ArrayList<Integer> b=new ArrayList<Integer>();
			for(int j=0;j<tr.getCloudset().getcNum();j++) {
				b.add(0);
			}
			sfc.add(b);
		}
		Solution s=new Solution(sf,sc,sm,sfc,td,tpc);
		this.solution=s;
		//ͨ���ӳ�̰�ķ����ɳ�ʼ��
			GenerateF();
			ArrayList<ArrayList<ArrayList<Integer>>> FClist=new ArrayList<ArrayList<ArrayList<Integer>>>();
			int t=1500;
			while(t>0) {
				ArrayList<ArrayList<Integer>> lamda=GenerateFC();
				if(!ifcontains(FClist,lamda)) {
					FClist.add(lamda);
				}
				t--;
			}
			System.out.println(FClist.size());
			Iterator<ArrayList<ArrayList<Integer>>> it =FClist.iterator();
			long start = System.currentTimeMillis();
	        while (it.hasNext()) {
	        	ArrayList<ArrayList<Integer>> lamda1=it.next();
	        	solution.setSolutionFC(lamda1);
				solution.setSolutionC(GenerateC());
				solution.setSolutionM(GenerateM());
				if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), solution.getSolutionF(), solution.getSolutionC(), solution.getSolutionFC())&&
				ValidationChecking.fogChecking(tr.getFogset(), solution.getSolutionF())&&
				ValidationChecking.cloudChecking(tr.getCloudset(), solution.getSolutionC(), solution.getSolutionM())&&
				ValidationChecking.communicationChecking(solution.getSolutionFC(), tr.getaM())) {
					
					long time1 = System.currentTimeMillis();
		//			System.out.println(start-time1);
					Formula.ComputeSolution(ff, nth, solution,table);
					solutionList.add(solution.copy());
					Formula.PrintResult(ff, nth, solution);
//					Formula.PrintResult(ff, nth, solution.copy());
					ParetoFront pf=new ParetoFront(solution.getTotalDelay(),solution.getTotalPowerConsumption());
		
					pf.setSolution(solution.copy());
					communicationlist.add(pf.copy());
					for(int i=0;i<communicationlist.size();i++) {
						communicationlist.get(i).getSolution().PrintSolution();
					}
					if(System.currentTimeMillis()-start>300000) break;
				}
				
	        }
	        FClist=null;
			
		}
	
	//����fog��
	public void GenerateF() {
		for(int i=0;i<tr.getFogset().getfNum();i++) {
			solution.getSolutionF().set(i, tr.getFogset().getFog(i).getMaxTaskNum());
		}
	}
//	public void GenerateF(int X) {
//		int X1=X;
//		int fNum=tr.getFogset().getfNum();
//		X=X/fNum;
//		boolean[] flag=new boolean[fNum];
//		for(int i=0;i<fNum;i++) {
//			solution.getSolutionF().set(i,X);
//			flag[i]=true;
//		}
//		
//		while(!ValidationChecking.fogChecking(tr.getFogset(),solution.getSolutionF())) {
//			int truenum=0;
//			int indexf=ValidationChecking.getIndexf();
//			int diff=solution.getSolutionF().get(indexf)-tr.getFogset().getFog(indexf).getMaxTaskNum();
//			solution.getSolutionF().set(indexf, tr.getFogset().getFog(indexf).getMaxTaskNum());
//			flag[indexf]=false;
//			for(int i=0;i<fNum;i++) {
//				if(flag[i]==true) {
//					truenum++;
//				}
//			}
//			for(int i=0;i<fNum;i++) {
//				if(flag[i]==true) {
//					solution.getSolutionF().set(i, solution.getSolutionF().get(i)+diff/truenum);
//				}
//				
//			}
//		}
//		int sum=0;
//		for(int i=0;i<fNum;i++) {
//			sum+=solution.getSolutionF().get(i);
//		}
//		if(sum!=X1) {
//			for(int i=0;i<fNum;i++) {
//				if(flag[i]==true) {
//					solution.getSolutionF().set(i, solution.getSolutionF().get(i)+(X1-sum));
//				}
//			}
//			ValidationChecking.fogChecking(tr.getFogset(),solution.getSolutionF());
//		}
//	}
	
	//�������Ʒ����
	public ArrayList<ArrayList<Integer>> GenerateFC(){
		Random r=new Random();
		ArrayList<ArrayList<Integer>> a=new ArrayList<ArrayList<Integer>>();
		double[][] d1=new double[tr.getdM().getCommuDelayMatrix().length][tr.getdM().getCommuDelayMatrix()[0].length];
		boolean[][] flag=new boolean[tr.getdM().getCommuDelayMatrix().length][tr.getdM().getCommuDelayMatrix()[0].length];
		for(int i=0;i<tr.getdM().getCommuDelayMatrix().length;i++) {
			for(int j=0;j<tr.getdM().getCommuDelayMatrix()[0].length;j++) {
				d1[i][j]=tr.getdM().getCommuDelay(i, j);
				flag[i][j]=true;
			}
		}
		int[][] lamda=new int[d1.length][d1[0].length];
		int[] y=new int[d1[0].length];
		Arrays.fill(y, 0);
		HashSet<Integer> number=new HashSet<Integer>();
		for(int i=0;i<d1.length;i++) {
			number.add(i);
		}
		while(number.size()!=0) {
			int i=r.nextInt(d1.length);
			if(number.contains(i)) {
				number.remove(i);//�����һ��
				int out=0;
				Arrays.sort(d1[i]);
				for(int j=0;j<d1[0].length;j++) {
					int v=r.nextInt(d1[0].length);
					while(d1[i][j]!=tr.getdM().getCommuDelay(i, v)||flag[i][v]==false) {//���dij���ظ������
						v=(v+1)%d1[0].length;
					}
					lamda[i][v]=min3(tr.getFogset().getFog(i).getTotalInput()-solution.getSolutionF().get(i)-out,tr.getaM().getMaxAllocation(i, v),tr.getYmax(v)-y[v]);
					flag[i][v]=false;
					out+=lamda[i][v];
					y[v]+=lamda[i][v];
				}
			}
			
		}
		
		for(int i=0;i<lamda.length;i++) {
			ArrayList<Integer> b=new ArrayList<Integer>();
			for(int j=0;j<lamda[0].length;j++) {
				b.add(lamda[i][j]);
			}
			a.add(b);
		}
		return a;	
	}	
	
	public int min3(int a,int b,int c) {
		int min1=Math.min(a, b);
		int min=Math.min(min1, c);
		return min;
	}
	
	public boolean ifcontains(ArrayList<ArrayList<ArrayList<Integer>>> FClist,ArrayList<ArrayList<Integer>> a) {
		boolean flag=true;
		Iterator<ArrayList<ArrayList<Integer>>> it =FClist.iterator();
		if(FClist.size()==0) {
			flag=false;
		}else {
			flag=false;
			while (it.hasNext()&&flag==false) {
				flag=true;
	        	ArrayList<ArrayList<Integer>> b=it.next();
	        	for(int i=0;i<a.size();i++) {
	        		for(int j=0;j<a.get(0).size();j++) {
	        			int a1=a.get(i).get(j);
	        			int b1=b.get(i).get(j);
	        			if(a1!=b1) {
	        				flag=false;
	        			}
	        		}
	        	}

	        }
			
		}
        return flag;
        
		
	}
	//����cloud��
	public ArrayList<Integer> GenerateC(){
		ArrayList<Integer> a=new ArrayList<Integer>();
		ArrayList<ArrayList<Integer>> lamda=solution.getSolutionFC();
		for(int i=0;i<lamda.get(0).size();i++) {
			int sum=0;
			for(int j=0;j<lamda.size();j++) {
				sum+=lamda.get(j).get(i);
			}
			a.add(sum);
		}
		return a;	
	}
	
	//���ɻ�������
	public ArrayList<Integer> GenerateM(){
		ArrayList<Integer> a=new ArrayList<Integer>();
		ArrayList<Integer> y=GenerateC();
		for(int i=0;i<y.size();i++) {
			if(solution.getSolutionC().get(i)!=0) {
				a.add((int)(y.get(i)/tr.getCloudset().getCloud(i).getFrequency())+1);
			}else {
				a.add(0);
			}
			
		}
		return a;	
	}
	
	
	public Solution GetInitialS() {
		Solution initial=solutionList.get(0);
		Iterator<Solution> it=solutionList.iterator();
		while(it.hasNext()) {
			Solution temp=it.next();
			if(temp.getTotalDelay()<initial.getTotalDelay()) {
				initial=temp;
			}
		}
		return initial;
	}
	
	
	
	public ArrayList<ParetoFront> getCommunicationlist() {
		return communicationlist;
	}

	public static void main(String[] args) {
//		String ff="5_3_5";
//		int nth=1;
//		String ff="4_6_2~4";
//		int nth=1;
//		CommuDelayGenerateIniSolution gs=new CommuDelayGenerateIniSolution(ff,nth);
//		int sum=0;
//		for(int i=0;i<gs.tr.getFogset().getfNum();i++) {
//			sum+=gs.tr.getFogset().getFog(i).getMaxTaskNum();
//		}
//			gs.run();
//		int min=Integer.MAX_VALUE;
//			for(int i=0;i<gs.tr.getFogset().getfNum();i++) {
//				if(min>gs.tr.getFogset().getFog(i).getMaxTaskNum()) {
//					min=gs.tr.getFogset().getFog(i).getMaxTaskNum();
//				}
//			}
//			gs.run(min*gs.tr.getFogset().getfNum()-200);
	}
}
