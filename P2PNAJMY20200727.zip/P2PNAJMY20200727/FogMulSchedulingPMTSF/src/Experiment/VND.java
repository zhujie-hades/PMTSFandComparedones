package Experiment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

import ParetoFront.ParetoFront;
import ParetoFront.ParetoFrontSet;
import Resources.TotalResource;
import Solution.Solution;
import Tools.Format;
import Tools.Formula;
import Tools.Io;
import Tools.ValidationChecking;

public class VND {
	ParetoFrontSet communicationset;
	ParetoFrontSet consumptionset;
	ParetoFrontSet pfList;
//	ParetoFrontSet spfList;
	String str="VNDImprove";
	String ff;
	int nth;
	TotalResource tr;
	int ifkxi;
	public long ECtime=0;
	Table<Integer,Integer,Double> table;
	public VND(String ff,int nth, ArrayList<ParetoFront> communicationlist,  ArrayList<ParetoFront> consumptionlist,Table<Integer,Integer,Double> table) {
		this.ff=ff;
		this.nth=nth;
		this.table=table;
		this.ifkxi=0;
		this.communicationset = new ParetoFrontSet(ff,nth);
		communicationset.setSet(communicationlist);
		this.consumptionset = new ParetoFrontSet(ff,nth);
		consumptionset.setSet(consumptionlist);
		TotalResource tr=new TotalResource(ff,nth);
		this.tr=tr;
//		spfList=new ParetoFrontSet(ff,nth);
		pfList=new ParetoFrontSet(ff,nth);
		pfList.getSet().add(new ParetoFront(Double.MAX_VALUE,Double.MAX_VALUE));
//		spfList.setSet(communicationset.getSet());
//		spfList.setSet(consumptionset.getSet());
		pfList.mergeWithSet(consumptionset);
		pfList.mergeWithSet(communicationset);
		
	}
	
/*	public int countshort(Solution solution,int i) {
		int count=0;
		ArrayList<Integer> solutionFC=solution.getSolutionFC().get(i);
		int fvalue=solution.getSolutionF().get(i);
		if(fvalue<(int)(tr.getFogset().getFog(i).getMaxTaskNum()*0.8)) {
			count++;
		}
		for(int p=0;p<tr.getCloudset().getcNum();p++) {
			if(solution.getSolutionFC().get(i).get(p)<tr.getaM().getMaxAllocation(i, p)) {
				count++;
			}
		}
		return count;
	}*/
	
	//�ܽ�������������destination����
	public ArrayList<Integer> receptindex(Solution solution,int i){
		ArrayList<Integer> a=new ArrayList<Integer>();
		int fvalue=solution.getSolutionF().get(i);
		if(fvalue<(int)(tr.getFogset().getFog(i).getMaxTaskNum()*0.8)) {
			a.add(tr.getCloudset().getcNum());
		}
		for(int p=0;p<tr.getCloudset().getcNum();p++) {
			if(solution.getSolutionFC().get(i).get(p)<tr.getaM().getMaxAllocation(i, p)) {
				a.add(p);
			}
		}
		return a;
	}
	
/*	public ParetoFrontSet neighbor(ParetoFront pf) {
		ParetoFrontSet neighborset=new ParetoFrontSet(ff,nth);
		int fNum=pf.getSolution().getSolutionF().size();
		int cNum=pf.getSolution().getSolutionC().size();
		for(int i=0;i<fNum;i++) {
			int divnum=countshort(pf.getSolution(),i);
			ArrayList<Integer> rejectset=receptindex(pf.getSolution(),i);
			for(int j=0;j<=cNum;j++) {
				ParetoFront pfcopy=pf.copy();
				if(j!=cNum) {
					int value=pfcopy.getSolution().getSolutionFC().get(i).get(j);
					if(value>0) {
						int d=(int)(value/10);
						int ave=d/divnum;
						if(!rejectset.contains(cNum)) {
							pfcopy.getSolution().getSolutionF().set(i, pfcopy.getSolution().getSolutionF().get(i)+ave);
						}
						for(int p=0;p<cNum;p++) {
							if(p!=j) {
								if(!rejectset.contains(p)) {
									pfcopy.getSolution().getSolutionFC().get(i).set(p, pfcopy.getSolution().getSolutionFC().get(i).get(p)+ave);
								}
							}else {
								pfcopy.getSolution().getSolutionFC().get(i).set(j, value-ave*cNum);
							}
						}
					}
				}else {
					int value=pfcopy.getSolution().getSolutionF().get(i);
					if(value>0) {
						int d=(int)(value/10);
						int ave=d/divnum;
						pfcopy.getSolution().getSolutionF().set(i, value-ave*cNum);
						for(int p=0;p<cNum;p++) {
							if(!rejectset.contains(p)) {
								pfcopy.getSolution().getSolutionFC().get(i).set(p, pfcopy.getSolution().getSolutionFC().get(i).get(p)+ave);
							}
								
						}
						
					}
				}
				GenerateC(pfcopy.getSolution());
				GenerateM(pfcopy.getSolution());
				if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionFC())&&
						ValidationChecking.fogChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF())&&
						ValidationChecking.cloudChecking(tr.getCloudset(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionM())&&
						ValidationChecking.communicationChecking(pfcopy.getSolution().getSolutionFC(), tr.getaM())) {
					Formula.ComputeSolution(ff, nth, pfcopy.getSolution());
					Formula.PrintResult(ff, nth, pfcopy.getSolution());
					pfcopy.setTotalDelay(pfcopy.getSolution().getTotalDelay());
					pfcopy.setTotalPowerConsumption(pfcopy.getSolution().getTotalPowerConsumption());
					neighborset.getSet().add(pfcopy.copy());
				}
				
			}
		}
		return neighborset;
	}*/
	
	public ParetoFrontSet neighbor(ParetoFront pf1, int kxi, int nh) {
		ParetoFrontSet neighborset=new ParetoFrontSet(ff,nth);
		int fNum=pf1.getSolution().getSolutionF().size();
		int cNum=pf1.getSolution().getSolutionC().size();
		pf1.getSolution().PrintSolution();
		for(int i=0;i<fNum;i++) {		
			ArrayList<Integer> receptset=receptindex(pf1.getSolution(),i);
			for(int j=0;j<=cNum;j++) {
//				ParetoFront pf=pf1.copy();
				if(j!=cNum) {
					int value=pf1.getSolution().getSolutionFC().get(i).get(j);
					if(value>0) {
						int d=(int)(value/kxi*nh);
						int ave=d/2;
						for(int m=0;m<receptset.size();m++) {
							for(int n=m+1;n<receptset.size();n++) {
								ParetoFront pfcopy=pf1.copy();
								if(receptset.get(m)==cNum||receptset.get(n)==cNum) {
									if(receptset.get(m)==cNum) {
										pfcopy.getSolution().getSolutionF().set(i, pfcopy.getSolution().getSolutionF().get(i)+ave);
										pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(n), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(n))+ave);
									}else {
										pfcopy.getSolution().getSolutionF().set(i, pfcopy.getSolution().getSolutionF().get(i)+ave);
										pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(m), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(m))+ave);
									}
								}else {
									pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(m), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(m))+ave);
									pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(n), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(n))+ave);
								}
								pfcopy.getSolution().getSolutionFC().get(i).set(j, value-ave*2);
								GenerateC(pfcopy.getSolution());
								GenerateM(pfcopy.getSolution());
								if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionFC())&&
										ValidationChecking.fogChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF())&&
										ValidationChecking.cloudChecking(tr.getCloudset(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionM())&&
										ValidationChecking.communicationChecking(pfcopy.getSolution().getSolutionFC(), tr.getaM())) {
									pfcopy.getSolution().PrintSolution();
									Formula.ComputeSolution(ff, nth, pfcopy.getSolution(),table);
									ECtime+=Formula.ECtime;
									Formula.PrintResult(ff, nth, pfcopy.getSolution());
									pfcopy.setTotalDelay(pfcopy.getSolution().getTotalDelay());
									pfcopy.setTotalPowerConsumption(pfcopy.getSolution().getTotalPowerConsumption());
									neighborset.getSet().add(pfcopy.copy());
								}
							}
						}
					}
				}else {
					receptset.remove(Integer.valueOf(cNum));
					int value=pf1.getSolution().getSolutionF().get(i);
					if(value>0) {
						int d=(int)(value/kxi*nh);
						int ave=d/2;
						for(int m=0;m<receptset.size();m++) {
							for(int n=m+1;n<receptset.size();n++) {
								ParetoFront pfcopy=pf1.copy();
								pfcopy.getSolution().getSolutionF().set(i, value-ave*2);								
									pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(m), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(m))+ave);
									pfcopy.getSolution().getSolutionFC().get(i).set(receptset.get(n), pfcopy.getSolution().getSolutionFC().get(i).get(receptset.get(n))+ave);								
									GenerateC(pfcopy.getSolution());
									GenerateM(pfcopy.getSolution());
									if(ValidationChecking.OffloadBalanceChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionFC())&&
											ValidationChecking.fogChecking(tr.getFogset(), pfcopy.getSolution().getSolutionF())&&
											ValidationChecking.cloudChecking(tr.getCloudset(), pfcopy.getSolution().getSolutionC(), pfcopy.getSolution().getSolutionM())&&
											ValidationChecking.communicationChecking(pfcopy.getSolution().getSolutionFC(), tr.getaM())) {
										Formula.ComputeSolution(ff, nth, pfcopy.getSolution(),table);
										ECtime+=Formula.ECtime;
										Formula.PrintResult(ff, nth, pfcopy.getSolution());
										pfcopy.setTotalDelay(pfcopy.getSolution().getTotalDelay());
										pfcopy.setTotalPowerConsumption(pfcopy.getSolution().getTotalPowerConsumption());
										neighborset.getSet().add(pfcopy.copy());
									}
							}				
					}
				}
					receptset.add(cNum);	
			}
	
		}
		
	}
		return neighborset;
}	
	//����cloud��
	public void GenerateC(Solution solution){
		ArrayList<Integer> a=new ArrayList<Integer>();
		ArrayList<ArrayList<Integer>> lamda=solution.getSolutionFC();
		for(int i=0;i<lamda.get(0).size();i++) {
			int sum=0;
			for(int j=0;j<lamda.size();j++) {
				sum+=lamda.get(j).get(i);
			}
			a.add(sum);
		}
			solution.setSolutionC(a);
	}
	
	//���ɻ�������
	public void GenerateM(Solution solution){
		ArrayList<Integer> a=new ArrayList<Integer>();
		ArrayList<Integer> y=solution.getSolutionC();
		for(int i=0;i<y.size();i++) {
			if(solution.getSolutionC().get(i)!=0) {
				a.add((int)(y.get(i)/tr.getCloudset().getCloud(i).getFrequency())+1);
			}else {
				a.add(0);
			}
			
		}
		solution.setSolutionM(a);
	}
	
	public boolean ifpfTrue() {
		boolean flag1=false;
		for(int i=0;i<pfList.getSet().size();i++) {
			if(pfList.getSet().get(i).getFlag()==true) {
				flag1=true;
				break;
			}
		}
		return flag1;
	}
	
	public void run(long start, int kxi) {
		while(ifpfTrue()) {
			ParetoFrontSet betterset=new ParetoFrontSet(ff,nth);
			ParetoFront itpf;
			Iterator<ParetoFront> iti = pfList.getSet().iterator();
			do{
				itpf=iti.next();
			}while(itpf.getFlag()==false);
			betterset=VNDM(itpf,kxi);
			itpf.setFlag(false);
			pfList.mergeWithSet(betterset);						
		    System.out.println(pfList.getSet().size());			
			if(System.currentTimeMillis()-start-ECtime>900) break;
		}

	}
	
	public ParetoFrontSet VNDM(ParetoFront itpf,int kxi) {
		ParetoFrontSet betterset=new ParetoFrontSet(ff,nth);
		ParetoFront pfcopy=itpf.copy();
		int k=1;
		while(k<=kxi) {
			ParetoFrontSet neighborset=neighbor(pfcopy,kxi,k);
			boolean flag=false;
			for(int j=0;j<neighborset.getSet().size();j++) {
                  if(neighborset.getSet().get(j).getTotalDelay()<=pfcopy.getTotalDelay()&&neighborset.getSet().get(j).getTotalPowerConsumption()<=pfcopy.getTotalPowerConsumption()) {
                	ParetoFrontSet temp=new ParetoFrontSet(ff,nth);
                	pfcopy=neighborset.getSet().get(j).copy();
                	temp.getSet().add(neighborset.getSet().get(j));
					betterset.mergeWithSet(temp);
					flag=true;
					break;
				}
			}
			if(flag!=true) {
				k=k+1;
			}else {
				k=1;
			}
		}
		return betterset;
	}
	
	
	
	public ParetoFrontSet getPfList() {
		return pfList;
	}

	public void setPfList(ParetoFrontSet pfList) {
		this.pfList = pfList;
	}
	
	public void print() throws IOException {
		Iterator<ParetoFront> it=pfList.getSet().iterator();
		while(it.hasNext()) {
			ParetoFront temp=it.next();
			System.out.println(temp);
			String[][] str= {{Double.toString(temp.getTotalDelay()),Format.formatbig(temp.getTotalPowerConsumption())}};
			Io.WriteFile(Io.location2,"ParetoFrontvns_"+ff, str);
			temp.getSolution().PrintSolution();
		}
		Io.WriteFile(Io.location2, "ParetoFrontvns_"+ff, Io.separa);
		Iterator<ParetoFront> it2=pfList.getSet().iterator();
		while(it2.hasNext()) {
			ParetoFront temp=it2.next();
			String[][] str= {{String.format("%.6f", temp.getDelay_arpd()),String.format("%.6f", temp.getPowerconsumption_arpd())}};
			Io.WriteFile(Io.location2,"ParetoFrontvns_"+ff, str);
			
		}
		Io.WriteFile(Io.location2, "ParetoFrontvns_"+ff, Io.separa);
	}

	public static void main(String[] args) {
		String ff="1_2_0~2";
		int nth=2;
		Table<Integer,Integer,Double> table=HashBasedTable.create();
		table.put(100, 0, 0.0);
		//delay
		double allocationpercent=0.1;
		CommuDelayGenerateIniSolution gscommu=new CommuDelayGenerateIniSolution(ff,nth,table);
		gscommu.run();
		
		long start = System.currentTimeMillis();
		CommuDelayImprove improve=new CommuDelayImprove(ff,nth,gscommu.GetInitialS(),allocationpercent,gscommu.communicationlist,table);
		improve.runCommu();
		long commutime=System.currentTimeMillis()-start-improve.getECtime();
		
		//consumption
		double taskpercent=0.8;
		Solution initial;
		ConsumptionImprove	improve1=null;
		long consumtime=0;
			ConsumptionGenerateIniSolution gs=new ConsumptionGenerateIniSolution(ff,nth,table);
			gs.run();
			if(gs.solutionList.size()!=0){
				initial=gs.solutionList.get(0);
				Iterator<Solution> it=gs.solutionList.iterator();
	    		while(it.hasNext()) {
	    			Solution temp=it.next();
	    			if(temp.getTotalPowerConsumption()<initial.getTotalPowerConsumption()) {
	    				initial=temp;
	    			}
	    		}
	    		long start1 = System.currentTimeMillis();
	    		improve1=new ConsumptionImprove(ff,nth,initial,gs.sort,taskpercent,allocationpercent,gs.consumptionlist,table);
	    		improve1.runconsum();
	    		consumtime=System.currentTimeMillis()-start1-improve1.ECtime;
			}
		
		
		//VNS
		long start2 = System.currentTimeMillis();
		VND vnsimprove=new VND(ff,nth,improve.pfList,improve1.pfList,table);
		vnsimprove.run(start2,3);
		long vnstime=System.currentTimeMillis()-start2-vnsimprove.ECtime;

	}
}
